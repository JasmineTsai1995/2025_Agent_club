env_path=/cxi_env/SNA_Claim
PIP_SERVER=${PIP_SERVER}
rm  -rf $env_path

python3.6 -m virtualenv --python=python3.6 $env_path
source $env_path/bin/activate

pip3.6 install --upgrade pip -i http://$PIP_SERVER:8081/repository/pypi-group/simple --trusted-host $PIP_SERVER

pip3.6 install -r $(pwd)/requirements.txt -i http://$PIP_SERVER:8081/repository/pypi-group/simple --trusted-host $PIP_SERVER
