import networkx as nx
import datetime
import os
import math 
import pandas as pd

class NetworkxManager:
    
    def __init__(self):
        self.G = nx.MultiGraph()

    def close(self):
        self.G.clear()

    ### create database: create nodes, index, relationships, simulated data ###
    # 0. create nodes
    def create_nodes(self, file_location, node_name, node_type=None):
        """
        node_name: one column name in csv file
        node_type: Person, Vehicle, ReportedCase
        """
        df_node = pd.read_csv(file_location)
        df_node = df_node.dropna(subset=[node_name])
        list_node = []
        for i in df_node.index:
            node_info = dict(df_node.loc[i])
            node_info['node_type'] = node_type
            list_node.append((df_node[node_name][i], node_info))
        self.G.add_nodes_from(list_node)
        
    ### 0. create relationships
    def create_relationships(self, file_location,
                             node_name1, node_name2,
                             relationship_type):
        """
        node_name1, node_name2: one column name in csv file
        relationship_type: DRIVES, PAYS, INSURES...
        """
        df_rel = pd.read_csv(file_location)
        df_rel = df_rel[[node_name1, node_name2]]
        df_rel = df_rel.dropna().reset_index(drop=True)
        list_rel = df_rel.values.tolist()
        self.G.add_edges_from(list_rel, relationship_type=relationship_type)
        
    ### reset database: delete all nodes, drop indices ###
    # 0. delete all nodes
    def delete_all_nodes(self):
        self.G.clear()

    ### data cleaning: 
    # 0. delete relationships with node_type and node_value
    def delete_relationships(self, node_value):
        if node_value not in list(self.G.nodes()):
            # print('there is no node_value in Graph')
            return None
        node_info = self.G.nodes.data()[node_value]
        self.G.remove_node(node_value)
        self.G.add_nodes_from([(node_value, node_info)])
        
    # 0. delete relationships with node_type and node_value containing
    def delete_relationships_contain(self, node_type, node_value):
        if node_type == 'Person':
            index_key = 'id'
        elif node_type == 'Vehicle':
            index_key = 'car_no'
        elif node_type == 'ReportedCase':
            index_key = 'report_number'

        list_node_info = list(dict(self.G.nodes.data()).values())
        for i in list_node_info:
            if ('node_type' in i.keys()) and node_type==i['node_type'] and (node_value in i[index_key]):
                node = i[index_key]
                self.delete_relationships(node)                   
        
    # 0. delete relationships with node_type and node_value with size greater than x
    def delete_relationships_on_size(self, node_type, relationship, size=10):
        nodes_to_remove = [
            node for node in self.G.nodes()
            if sum(1 for _, _, data in self.G.edges(node, data=True) if data.get('relationship_type') == relationship) > size
        ]
        for node in nodes_to_remove:
            self.delete_relationships(node) 
    

        
        
        
        
        
    ### produce elements of groups ###
    ## 0. check state
    def all_node_number(self):
        return self.G.number_of_nodes()

    ## 0. find groups
    def find_groups(self, node_id):
        related_nodes = nx.dfs_tree(self.G, source=node_id).nodes()
        return list(related_nodes)

    ## 0. compute sum of all rules
    def compute_rule_sum(self, node_id, threshold=10):
        location = os.environ['NEO4J_IMPORT_PATH']+'Smart_claim/node_ReportedCase.csv'
        with open(location) as fr:
            column_name = fr.readline().rstrip('\n')
        column_name_list = column_name.split(sep=',')
        rule_list = [r for r in column_name_list if 'rule_' in r]
        related_nodes = nx.dfs_tree(self.G, source=node_id).nodes()
        count_case = 0

        for node in related_nodes:
            tmp_sum = 0
            if 'node_type' in self.G.nodes[node].keys() and self.G.nodes[node]['node_type']=='ReportedCase':

                # get intersection list between node_ReportedCase.csv column name and node attributes 
                intersection = list(set(rule_list) & set(self.G.nodes[node].keys()))
                for rule in intersection:
                    tmp_sum += self.G.nodes[node][rule]

            if tmp_sum>threshold:
                count_case += 1
        return [count_case]
    
    def return_group_info(self, rep_number):
        year_1 = int(datetime.datetime.now().strftime('%Y'))-1
        year_2 = int(datetime.datetime.now().strftime('%Y'))-2
        year_3 = int(datetime.datetime.now().strftime('%Y'))-3
        related_nodes = nx.dfs_tree(self.G, source=rep_number).nodes()

        # 1-2
        size_node = len(related_nodes)
        # size_edge = len(G.edges())
        # 3-7
        car_counts, id_counts, rep_counts = 0, 0, 0 
        total_amount, average_amount = 0, 0
        # 8-16
        sum_type_1, sum_type_2, sum_type_3 = 0, 0, 0
        sum_type_4, sum_type_5, sum_type_6 = 0, 0, 0
        sum_type_7, sum_type_8, sum_type_9 = 0, 0, 0
        # 17-19 
        sum_year_1, sum_year_2, sum_year_3 = 0, 0, 0

        for node in related_nodes:
            if 'node_type' in self.G.nodes[node].keys() and self.G.nodes[node]['node_type']=='Vehicle':
                car_counts += 1
            elif 'node_type' in self.G.nodes[node].keys() and self.G.nodes[node]['node_type']=='Person':
                id_counts += 1
            elif 'node_type' in self.G.nodes[node].keys() and self.G.nodes[node]['node_type']=='ReportedCase':
                rep_counts += 1
                if int(self.G.nodes[node]['yyyy']) == year_1:
                    sum_year_1 += 1
                elif int(self.G.nodes[node]['yyyy']) == year_2:
                    sum_year_2 += 1
                elif int(self.G.nodes[node]['yyyy']) == year_3:
                    sum_year_3 += 1
                sum_type_1 += int(self.G.nodes[node]['type_1'])
                sum_type_2 += int(self.G.nodes[node]['type_2'])
                sum_type_3 += int(self.G.nodes[node]['type_3'])
                sum_type_4 += int(self.G.nodes[node]['type_4'])
                sum_type_5 += int(self.G.nodes[node]['type_5'])
                sum_type_6 += int(self.G.nodes[node]['type_6'])
                sum_type_7 += int(self.G.nodes[node]['type_7'])
                sum_type_8 += int(self.G.nodes[node]['type_8'])
                sum_type_9 += int(self.G.nodes[node]['type_9'])
                total_amount += int(self.G.nodes[node]['total_conclude_amount'])
        average_amount = total_amount/rep_counts
        type_1_ratio = sum_type_1/rep_counts
        type_2_ratio = sum_type_2/rep_counts
        type_3_ratio = sum_type_3/rep_counts
        type_4_ratio = sum_type_4/rep_counts
        type_5_ratio = sum_type_5/rep_counts
        type_6_ratio = sum_type_6/rep_counts
        type_7_ratio = sum_type_7/rep_counts
        type_8_ratio = sum_type_8/rep_counts
        type_9_ratio = sum_type_9/rep_counts
        year_1_ratio = sum_year_1/rep_counts
        year_2_ratio = sum_year_2/rep_counts
        year_3_ratio = sum_year_3/rep_counts

        result = [size_node, car_counts, id_counts, rep_counts,
                 total_amount, average_amount,
                 type_1_ratio, type_2_ratio, type_3_ratio,
                 type_4_ratio, type_5_ratio, type_6_ratio,
                 type_7_ratio, type_8_ratio, type_9_ratio,
                 year_1_ratio, year_2_ratio, year_3_ratio]
        return result
        
    ## 0. find relationship size
    def find_relationship_size(self, node_id):
        related_nodes = nx.dfs_tree(self.G, source=node_id).nodes()
        edge_counts = 0
        for node in related_nodes:
            edges = self.G.edges(node, data=False)
            edge_counts += len(edges)
        return [int(edge_counts/2)]
    
    
