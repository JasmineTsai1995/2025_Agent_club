#from __future__ import print_function
#from __future__ import unicode_literals
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
from pyspark.sql import SparkSession
from pyspark import SparkConf
from pyspark.sql import Row
from pyspark.sql.window import Window
from pyspark.sql.types import IntegerType, FloatType, LongType, StringType, MapType
from pyspark.sql.types import StructType, StructField, StringType
import numpy as np
import time
import datetime
#import calendar
#import gc
import getpass
import pandas as pd
import subprocess
import os
import cxi_hap

class TableManager():
    
    def __init__(self):
        # self.spark = SparkSession.builder.master("yarn").appName("CXI_ETL").enableHiveSupport().getOrCreate()       
        self.spark_obj = cxi_hap.base()
        self.spark_obj.sc_conf.set("spark.executor.instances", 4)
        self.spark_obj.sc_conf.set("spark.executor.memory", "20g")
        self.spark_obj.sc_conf.set("spark.network.timeout", 300)
        self.spark = self.spark_obj.get_SparkSession()
        if getpass.getuser() == 'pcxietl':
            self.table_name = 'cxi'
            self.path = '/cxi/warehouse/cxi.db/'
        else:
            self.table_name = 'cxi_user'
            self.path = '/cxi/warehouse/cxi_user.db/'

    def close_spark(self):
        self.spark.stop()
        
    def equivalent_type(self, f):
        if f == 'datetime64[ns]': return DateType()
        elif f == 'int64': return LongType()
        elif f == 'int32': return IntegerType()
        elif f == 'float64': return FloatType()
        else: return StringType()
        
    def define_structure(self, string, format_type):
        try: typo = self.equivalent_type(format_type)
        except: typo = StringType()
        return StructField(string, typo)
        
    def pandas_to_spark(self, pandas_df):
        columns = list(pandas_df.columns)
        types = list(pandas_df.dtypes)
        struct_list = []
        for column, typo in zip(columns, types):
            struct_list.append(self.define_structure(column, typo))
            p_schema = StructType(struct_list)
            return(self.spark.createDataFrame(pandas_df, p_schema))
        # equivalent to: py_table = spark.createDataFrame(table)

    def loadFromHDFS(self, target, sql_location, neo4j_import_location):
        #start = time.time()
        sql = sql_location + target + ".sql"
        with open(sql) as fr:
            query = fr.read()
            query = query.replace("cxi_v_user","cxi")
        df = self.spark.sql(query).toPandas()
        df.to_csv(neo4j_import_location + target + ".csv", index=False)
        #print(str(time.time()-start) + "s taken to load " + target)
        return(df.shape[0])

    def fetch(self, query):
        df = self.spark.sql(query).toPandas()
        return(df)
    
    def fetch_new_rep(self, target, sql_location, time_period):
        sql = sql_location + target
        data_date = (datetime.datetime.today()-datetime.timedelta(days=time_period+1)).strftime('%Y-%m-%d')
        with open(sql) as fr:
            query = fr.read()
            query = query.format(data_date=data_date)
        df = self.spark.sql(query).toPandas()
        l = df['report_number'].tolist()
        return(l)

    def run_cmd(self, cmd):
        pcmd = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                universal_newlines=True,
                                shell=True)
        output, err = pcmd.communicate()
        return_code = pcmd.wait()
        if (return_code!=0):
            output = err
        return(return_code, str(output))

    def putToHDFS(self, content, date, table , file_path):
        
        cmd = ''
        hdfs_path = "/cxi/warehouse/" + table.split('.')[0] + '.db/' + table.split('.')[-1] + "/"
        hdfs_path += 'sna_upd_dttm=' + str(date) + '/'
        cmd += 'hdfs dfs -mkdir -p ' + hdfs_path + ';'
        cmd += 'hdfs dfs -rm -f -R ' + hdfs_path + '/*;'
        cmd += 'hdfs dfs -put ' + file_path + ' ' + hdfs_path + ' ;'
        return_code, output = self.run_cmd(cmd)
        if (return_code!=0):
            raise Exception(output)
        self.spark.sql("""msck repair table """ + table)

    def saveToHDFS(self, content, date, table ):
        pydf = self.pandas_to_spark(content)
        path = '/cxi/warehouse/' + table.split('.')[0] + '.db/' + table.split('.')[-1] 
        pydf.write.mode("overwrite").saveAsTable(table)
        
    def drop_table(self, db_loaction):
        self.spark.sql("drop table " + db_loaction)
        
    def create_schema(self, partition, db_location, column_names):
        self.spark.sql("create table if not exists " + db_location + " (" + column_names + ") " + "partitioned by (sna_upd_dttm string) row format delimited fields terminated by ',' stored as textfile")
        self.spark.sql("""msck repair table """ + db_location)      
        self.spark.sql("""alter table """ + db_location + """ drop if exists partition (sna_upd_dttm='""" + partition + """')""")
        
        
    def upload_tbl_log(self, project='test', table='table',
                       start_time=datetime.datetime.now(), end_time=datetime.datetime.now(),
                       row_cnt='0', col_cnt='0',
                       status='succeed', memo=['step1 ok.','step2 ok.']):
        if (project=='test' or table=='table'):
            raise Exception("[upload_tbl_log] 未正確傳入參數!")
        info = pd.DataFrame({'project': project, 'table': table,
                             'start_time': start_time.strftime('%Y-%m-%d %H:%M:%S'),
                             'end_time': end_time.strftime('%Y-%m-%d %H:%M:%S'),
                             'time_taken': (end_time-start_time).seconds,
                             'row_cnt': row_cnt, 'col_cnt': col_cnt,
                             'status': [status],
                             'memo': str(memo)})
        info['yyyymmdd'] = datetime.date.today().strftime('%Y%m%d')
        df = self.spark.createDataFrame(info)
        df.write.mode("append").saveAsTable(os.environ['HIVE_SCHEMA']+'.ap_tbl_log')
