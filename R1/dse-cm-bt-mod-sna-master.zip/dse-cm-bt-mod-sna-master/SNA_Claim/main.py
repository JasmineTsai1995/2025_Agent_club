## add timestamps############################### test parameters ############################################
is_resetting_networkx = True
is_uploading_HDFS = True
############################### setups #####################################################
## Import standard python libraries
import logging
import numpy as np
import pandas as pd
import threading
import time
import os
import getpass
import datetime
from datetime import date, timedelta
from scipy.stats import rankdata
import sys

## Import 2 modules
from TableManagement import TableManager
from NetworkxManagement import NetworkxManager

## set paths
graph_import_location = os.environ['NEO4J_IMPORT_PATH']+"Smart_claim/"
db_location = os.environ['HIVE_SCHEMA']+".clm_sna_attr"
db_location_info = os.environ['HIVE_SCHEMA']+".clm_sna_info"
WORKER_PATH = os.getcwd()
sql_location = WORKER_PATH+"/sql/"
clm_sna_attr_path = WORKER_PATH+"/clm_sna_attr.csv"
clm_sna_info_path = WORKER_PATH+"/clm_sna_info.csv"
clm_sna_stats_path = WORKER_PATH+"/clm_sna_stats.csv"

## set api parameters (to pass in parameters from bash)
args = sys.argv 

## set default values
time_period_def = 3
threshold_rb = 3
status = 'succeeded'

############################### extra functions ############################################

## memo.log control
def printx(message):
	if (os.environ['HIVE_SCHEMA'] != 'cxi'):
		print(message)
		
## keep memos
class memox(list):
	def log(self, message):
		self.append(message)
		print(message)

################################### program starts #########################################

## start timing
start_stamp = datetime.datetime.now() #.strftime('%Y-%m-%d %H:%M:%S')
start = time.time()
memo = memox()

## create objects (modules)
tm = TableManager()
nwx = NetworkxManager()
		
######################### start building networkx database #####################################

if (is_resetting_networkx==True):
	memo.log(" ## Start: loading data from HDFS, at "
			 + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

	######### import data from HDFS ##########
	## load nodes from HDFS
	tm.loadFromHDFS("node_Vehicle", sql_location, graph_import_location)
	tm.loadFromHDFS("node_Person", sql_location, graph_import_location)
	row_counts = tm.loadFromHDFS("node_ReportedCase", sql_location, graph_import_location)

	#============== missing value quick check + quick imputation============================#
	df = pd.read_csv(graph_import_location + "node_ReportedCase.csv")
	missing = df.isnull().sum()
	missing_columns = df.columns[missing != 0]
	missing_counts = missing[missing!=0]
	if(len(missing) > 0):
		memo.log("Warning! There are " + str(len(missing_columns))
				 + " columns containing missing values. \n"
				 + "Counts: " + str(missing_counts))
	df = df.fillna(0)
	df.to_csv(graph_import_location + "node_ReportedCase.csv", header=True, index=False)
	#============== check duplicates (report number) =======================================#
	rep_duplicated_len = len(df[df.report_number.duplicated()])
	if(rep_duplicated_len > 0):
		memo.log("Warning! There are " + str(rep_duplicated_len) + " duplicate report numbers.")
	#=======================================================================================#	

	## load relationships from HDFS
	tm.loadFromHDFS("rel_causes", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_drives", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_insured", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_involves", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_apc_of", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_pays", sql_location, graph_import_location)
	tm.loadFromHDFS("rel_owns_bank", sql_location, graph_import_location)

	## create simulated data (create_relationships somehow don't run without running something small first)
	x = ["simulated_car_no"] * 50
	y = ["simulated_id"] * 50
	df_simulated = pd.DataFrame({'car_no': x, 'id': y})
	df_simulated.to_csv(graph_import_location + "rel_simulated.csv", index=False)

	## all data needed is ready. record time stamp and print messages.
	memo.log(" # Finish: loading data from HDFS, at "
		  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

	######### clean everything in Networkx ##########
	memo.log(" ## Start: setting up Networkx, at "
		  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

	## get number of existing nodes in networkx
	total_node_number = nwx.all_node_number()

	## if there is any node in networkx, delete everything (to recreate it later)
	if total_node_number > 0:
		nwx.delete_all_nodes()


	######### create nodes/indices/relationships in Networkx ##########
	## create nodes in networkx
	nwx.create_nodes(file_location=os.path.join(graph_import_location, "node_ReportedCase.csv"), node_name='report_number', node_type="ReportedCase")
	nwx.create_nodes(file_location=os.path.join(graph_import_location, "node_Person.csv"), node_name='id', node_type="Person")
	nwx.create_nodes(file_location=os.path.join(graph_import_location, "node_Vehicle.csv"), node_name='car_no', node_type="Vehicle")

	# 1. relationship: drives
	nwx.create_relationships(os.path.join(graph_import_location, "rel_drives.csv"),
							"driver_customer_id", "car_no", "DRIVES")

	# 2. relationship: insures
	nwx.create_relationships(os.path.join(graph_import_location, "rel_apc_of.csv"),
							"apc_id", "car_no", "INSURES")

	# 3. relationship: is_insured_by
	nwx.create_relationships(os.path.join(graph_import_location, "rel_insured.csv"),
							"car_no", "ins_id", "IS_INSURED_BY")

	# 4. relationship: causes
	nwx.create_relationships(os.path.join(graph_import_location, "rel_causes.csv"),
							"car_no", "report_number", "CAUSES")

	# 5. relationship: involves
	nwx.create_relationships(os.path.join(graph_import_location, "rel_involves.csv"),
							"report_number", "oppsite_car_no", "INVOLVES")

	# 6. relationship: pays
	nwx.create_relationships(os.path.join(graph_import_location, "rel_pays.csv"),
							"report_number", "pay_id", "PAYS")

	# 7. relationship: owns bank
	nwx.create_relationships(os.path.join(graph_import_location, "rel_owns_bank.csv"),
							"bank_account", "oppsite_car_no", "OWNS_BANK")

	######### data cleaning ##########
	nwx.delete_relationships("?")
	nwx.delete_relationships("-")
	nwx.delete_relationships("XXX-XXX")
	nwx.delete_relationships("000-000")
	nwx.delete_relationships("0-0")
    
	nwx.delete_relationships_contain("Vehicle", "*")
	nwx.delete_relationships_on_size("Person", "PAYS", 10)
	nwx.delete_relationships_on_size("Person", "INSURES", 10)

	memo.log(" # Finish: setting up Networkx, at "
		  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	
###################### arguments check before creating final list ##########################
memo.log(" ## Start: producing list, at "
	  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

## argument 1: how many days (int) should I update? (default=3) (initial=all)
if (len(args)>1):
	if (args[1]=='initial'):
		rep = pd.read_csv(os.environ['NEO4J_IMPORT_PATH']+'Smart_claim/node_ReportedCase.csv',
						  usecols = ["report_number"])["report_number"].tolist()
	elif (args[1].isdigit()):
		rep = tm.fetch_new_rep("node_ReportedCase_updates.sql", sql_location,
							   time_period=int(args[1]))
else:
	rep = tm.fetch_new_rep("node_ReportedCase_updates.sql", sql_location, time_period=time_period_def)
	
## argument 2: how many data points (int) should I run? (default=all)
if (len(args)>2):
	if (args[2].isdigit()):
		rep = rep[0:int(args[2])]

################################# start creating list ############################## 
loop_n = len(rep)
if (loop_n==0): memo.log("Warning: there are no new report numbers to update.")

df_result = pd.DataFrame()

#print(rep)

for index, i in enumerate(rep):
	rep_number = pd.DataFrame({'report_number': nwx.find_groups(i)})
	suspicious_rep_counts = pd.DataFrame({'suspicious_rep_counts':
										  nwx.compute_rule_sum(i, threshold=threshold_rb)
										  * len(rep_number)})
	size_relationship = pd.DataFrame({'size_relationship':
									  nwx.find_relationship_size(i)
									  * len(rep_number)})
	group_no = pd.DataFrame({'group_no': [index] * len(rep_number)})
	group_info = pd.DataFrame(nwx.return_group_info(i)).T
	group_info = pd.DataFrame(np.repeat(group_info.values, len(rep_number), 0))
	result = pd.concat([group_no, rep_number, 
						suspicious_rep_counts, size_relationship, group_info],
					   axis=1, ignore_index=True)
	df_result = pd.concat([df_result, result])
	if (index % 100 == 0):
		printx("dev: {index}/{n}".format(index=str(index), n=str(loop_n)))
	elif (index % 100000 == 0):
		memo.log(" -- progress: {index}/{n}".format(index=str(index), n=str(loop_n)))

df_result.columns = ['group_no', 'report_number', 'suspicious_report',
					 'relationship_counts', 'node_counts', 
					 'vehicle_counts', 'id_counts', 'report_counts',
					 'total_conclude_amount', 'ave_conclude_amount',
					 'type_1', 'type_2', 'type_3', 'type_4', 'type_5', 'type_6',
					 'type_7', 'type_8', 'type_9', 
					 'report_ratio_times1', 'report_ratio_times2', 'report_ratio_times3']
if (is_resetting_networkx==False):
	df = pd.read_csv(graph_import_location + "node_ReportedCase.csv") # to comment out if read above

## use predefine columns: last_report_status, rules_sum
df_result = pd.merge(df_result, df[['report_number', 'last_report_status', 'rules_sum']],
					 on='report_number', how='inner')
df_result['suspicious_score'] = df_result['suspicious_report']/df_result['report_counts']
df_result.loc[df_result['report_counts']==1, 'suspicious_score'] = 0 # to exclude group with only 1 report number 
df_result['score_x_amount'] = df_result['suspicious_score'] * df_result['ave_conclude_amount']
df_result['suspicious_report'] = (df_result['rules_sum'] > 3).astype(int)
df_result = df_result.drop(['rules_sum'], axis=1)

## clean data types and column names & rounding
df_result = df_result.rename(columns={'last_report_status': 'report_status'}) # to reline
df_result = df_result.astype({'node_counts': 'int',
							  'relationship_counts': 'int',
							  'vehicle_counts': 'int',
							  'id_counts': 'int',
							  'report_counts': 'int',
							  'total_conclude_amount': 'int'})
col_float = ['type_1', 'type_2', 'type_3',
			 'type_4', 'type_5', 'type_6',
			 'type_7', 'type_8', 'type_9',
			 'report_ratio_times1', 'report_ratio_times2', 'report_ratio_times3']
df_result[col_float] = df_result[col_float] * 100

## rename & rearrange columns
column_names = ['group_no', 'report_number', 'report_status',
				'node_counts', 'relationship_counts',
				'report_counts', 'id_counts', 'vehicle_counts',
				'total_conclude_amount', 'ave_conclude_amount',
				'report_ratio_times1', 'report_ratio_times2', 'report_ratio_times3',
				'suspicious_report', 'suspicious_score', 'score_x_amount',
				'percentil_rank',
				'type_1', 'type_2', 'type_3', 'type_4', 'type_5',
				'type_6', 'type_7', 'type_8', 'type_9',
				'sna_upd_dttm']
df_result = df_result.reindex(columns=column_names)
df_result = df_result.drop_duplicates(['report_number'][0])

#df_result.to_csv('df_looped.csv', header=True, index=False)
############################## combine two lists #########################################
if not (len(args)>1 and args[1]=='initial'):
	today = datetime.date.today().strftime('%Y%m%d')
	latest = tm.fetch("SELECT MAX(sna_upd_dttm) FROM cxi.clm_sna_attr WHERE sna_upd_dttm <" + today)
	query_prev = "SELECT * FROM cxi.clm_sna_attr WHERE sna_upd_dttm = '" + str(latest.values[0][0]) + "'"
	#query_prev = "SELECT * FROM cxi_user_da.clm_sna_attr WHERE sna_upd_dttm = '20220114'"
	memo.log('query from: ' + query_prev)
	df_prev_full = tm.fetch(query_prev)
	#df_prev = pd.read_csv(clm_sna_attr_path) # if ever want to load from local
	memo.log('Counts of previous and additional new rows: ' + str(df_prev_full.shape[0]) + ' and ' + str(df_result.shape[0]))
	#memo.log('prev day alert cases: ' + str(df_prev.loc[(df_prev.report_status!=160)&(df_prev.percentil_rank>95)].shape[0]))
	df_result['group_no'] = df_result['group_no'] + max(df_prev_full['group_no']) + 1

	df_prev = df_prev_full[~df_prev_full['report_number'].isin(df_result['report_number'])]
	df_result_ori = pd.concat([df_prev, df_result])

	# stablise group number
	df_prev = df_prev.rename(columns={'group_no': 'group_1'})
	df_result = df_result.rename(columns={'group_no': 'group_2'})
	df3 = pd.merge(df_prev[['group_1', 'report_number']], df_result[['group_2', 'report_number']], on='report_number', how='outer')
	df4 = df3.groupby('group_2')
	df3.sort_values('group_1', inplace=True)
	latest = df3['group_1'].max() + 1
	indx = df3[df3['group_1'].isnull()].index.tolist()
	prev = df3.loc[indx[0]].group_2
	for idx in indx:
		if (df3.loc[idx].group_2 != prev):
			latest+=1
		df3.loc[idx, 'group_1'] = latest
		prev = df3.loc[idx].group_2
	df_result = df_result_ori.merge(df3, on='report_number', how='inner').drop(['group_2'], axis=1).sort_values('group_1').drop(['group_no'], axis=1)
	df_result = df_result.rename(columns={'group_1': 'group_no'})
	# reorder
	group_no = df_result['group_no']
	df_result.drop(labels=['group_no'], axis=1, inplace=True)
	df_result.insert(0, 'group_no', group_no)
	df_result.group_no = df_result.group_no.astype('int')
df_result = df_result.drop_duplicates(['report_number'][0])

## calculate pr
v = df_result['score_x_amount'].tolist()
df_result['percentil_rank'] = rankdata(v)*100/len(v)
df_result = df_result.round(1)
#memo.log('latest alert cases: ' + str(df_prev.loc[(df_prev.report_status!=160)&(df_prev.percentil_rank>95)].shape[0]))

## search id with pr>95 in previous table
if not (len(args)>1 and args[1]=='initial'):
	df_result['prev_percentil_rank'] = df_prev_full['percentil_rank'].astype(float)
	## compare value
	
	df_result['compare'] = df_result.prev_percentil_rank - df_result.percentil_rank
	df_result[df_result['compare']<0].prev_percentil_rank = df_result.percentil_rank[df_result['compare']<0] # 
	df_result.drop('compare', axis=1)

## add timestamps
date_yyyymmdd = datetime.date.today().strftime('%Y%m%d')
df_result['sna_upd_dttm'] = date_yyyymmdd

memo.log(" # Finish: producing list, at "
	  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

## error checking
if (is_resetting_networkx==True):
	if (df_result.shape[0]!=row_counts-rep_duplicated_len):
		memo.log('Warning: Source and result NOT equal in row no.')
		memo.log('Source: ' + str(row_counts-rep_duplicated_len))
		memo.log('Result: ' + str(df_result.shape[0]))

## duplicates checking
rep_duplicated_len = len(df_result[df_result.report_number.duplicated()])
if(rep_duplicated_len > 0):
	memo.log("Warning! There are " + str(rep_duplicated_len) + " duplicate report numbers.")

memo.log(" ## Start: exporting data and saving to HDFS, at "
	  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

# export to csv
df_result.to_csv(clm_sna_attr_path, index=False, header=False)

if (is_uploading_HDFS==True):
	df_prev_col = "group_no int, report_number string, report_status string, node_counts int, relationship_counts int, report_counts int, id_counts int, vehicle_counts int, total_conclude_amount int, ave_conclude_amount string, report_ratio_times1 string, report_ratio_times2 string, report_ratio_times3 string, suspicious_report int, suspicious_score string, score_x_amount string, percentil_rank string, type_1 string, type_2 string, type_3 string, type_4 string, type_5 string, type_6 string, type_7 string, type_8 string, type_9 string"
	tm.create_schema(date_yyyymmdd, db_location, df_prev_col)
	tm.putToHDFS(df_result, date_yyyymmdd, db_location, clm_sna_attr_path)

memo.log(" # Finish: exporting data and saving to HDFS, at "
	  + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
# info recording

project = 'clm_sna'
table = 'clm_sna_attr'
start_time = start_stamp 
end_time = datetime.datetime.now()
row_cnt = df_result.shape[0:1]
col_cnt = df_result.shape[1:2]
status = status
tm.upload_tbl_log(project=project, table=table, start_time=start_time, end_time=end_time,
			   row_cnt=row_cnt, col_cnt=col_cnt, status=status, memo=list(memo))
#### wrap up #### export again with headers.
df_result.to_csv(clm_sna_attr_path, index=False, header=True)

#sys.stdout.close()
del nwx
