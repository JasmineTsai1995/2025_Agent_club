with active_report as (
    select distinct A.report_number, A.insured_number,B.pay_type, C.insured_type, D.apc_type
    from (
        select distinct aaa040.report_number
                        ,aaa040.insured_number
                        ,aaa040.insured_sequence
                        ,abp001.contract_no
                        ,aaa040.policy_no
        from cxi.dtaaa040 aaa040
        left join cxi.dtabp001 abp001
          on aaa040.policy_no = abp001.policy_no
            where 1 = 1
            and aaa040.insured_number is not null
            and datediff(current_date, aaa040.appllte_date) <= 1095
            and aaa040.product_policy_code in ('CF01001', 'CF01002')
            and (aaa040.create_date >= '{data_date}' or aaa040.change_date >= '{data_date}')
    ) A
    left join (
    select distinct insured_number
                    ,insured_sequence
                    ,certific_no as pay_id
                    ,idntfctn_type as pay_type
    from cxi.dtaad017
        where 1 = 1
        and idntfctn_type not in ('4', '9')
        and substr(product_main_id, 1, 1) = 'C'
        and product_main_id not in ('CGB', 'CGA', 'CAL', 'C91', 'C92', 'C93', 'C94')
    ) B
    on A.insured_number = B.insured_number
    and A.insured_sequence = B.insured_sequence
    left join (
    select distinct contract_no
                    ,customer_id as insured_id
                    ,idntfctn_type as insured_type
    from cxi.dtabp004
        where 1 = 1
        and customer_classfy = '2'
        and idntfctn_type not in ('4', '9')
    ) C
    on A.contract_no = C.contract_no
    left join (
    select distinct contract_no
                    ,customer_id as apc_id
                    ,idntfctn_type as apc_type
    from cxi.dtabp004
        where 1 = 1
        and customer_classfy = '1'
        and idntfctn_type not in ('4', '9')
    ) D
    on A.contract_no = D.contract_no
)

,rule_clcltr as (
    select distinct rule.aply_no as rule_report
        ,case when rule.rule_1 <> '1' then '0' else rule.rule_1 end as rule_1
        ,case when rule.rule_2 <> '1' then '0' else rule.rule_2 end as rule_2
        ,case when rule.rule_4 <> '1' then '0' else rule.rule_4 end as rule_4
        ,case when rule.rule_5 <> '1' then '0' else rule.rule_5 end as rule_5
        ,case when rule.rule_6 <> '1' then '0' else rule.rule_6 end as rule_6
        ,case when rule.rule_7 <> '1' then '0' else rule.rule_7 end as rule_7
        ,case when rule.rule_8 <> '1' then '0' else rule.rule_8 end as rule_8
        ,case when rule.rule_9 <> '1' then '0' else rule.rule_9 end as rule_9
        ,case when rule.rule_10 <> '1' then '0' else rule.rule_10 end as rule_10
        ,case when rule.rule_11 <> '1' then '0' else rule.rule_11 end as rule_11
        ,case when rule.rule_12 <> '1' then '0' else rule.rule_12 end as rule_12
        ,case when rule.rule_13 <> '1' then '0' else rule.rule_13 end as rule_13
        ,case when rule.rule_14 <> '1' then '0' else rule.rule_14 end as rule_14
        ,case when rule.rule_15 <> '1' then '0' else rule.rule_15 end as rule_15
        ,case when rule.rule_19 <> '1' then '0' else rule.rule_19 end as rule_19
        ,case when rule.rule_20 <> '1' then '0' else rule.rule_20 end as rule_20
        ,case when rule.rule_21 <> '1' then '0' else rule.rule_21 end as rule_21
        ,case when rule.rule_23 <> '1' then '0' else rule.rule_23 end as rule_23
        ,case when rule.rule_24 <> '1' then '0' else rule.rule_24 end as rule_24
        ,case when rule.rule_25 <> '1' then '0' else rule.rule_25 end as rule_25
        ,case when rule.rule_26 <> '1' then '0' else rule.rule_26 end as rule_26
        ,case when rule.rule_27 <> '1' then '0' else rule.rule_27 end as rule_27
        ,case when rule.rule_28 <> '1' then '0' else rule.rule_28 end as rule_28
        ,case when rule.rule_29 <> '1' then '0' else rule.rule_29 end as rule_29
        ,case when rule.rule_30 <> '1' then '0' else rule.rule_30 end as rule_30
        ,case when rule.rule_31 <> '1' then '0' else rule.rule_31 end as rule_31
        ,case when rule.rule_32 <> '1' then '0' else rule.rule_32 end as rule_32
        ,cast(rule.crt_date_time as date) as create_date
        ,cast(rule.upt_date_time as date) as change_date
        ,cast(rule.processed_dttm as date) as processed_dt
    from cxi.clm_rb_result rule
        where 1 = 1
                and (cast(rule.crt_date_time as date) >= '{data_date}'
                    or cast(rule.upt_date_time as date) >= '{data_date}')
)

,rule_results as (
    select distinct rels.*
                    ,sum(rels.rule_1 + rels.rule_2 + rels.rule_4 + rels.rule_5 + rels.rule_6 + rels.rule_7 +
                    rels.rule_8 + rels.rule_9 + rels.rule_10 + rels.rule_11 + rels.rule_12 + rels.rule_13 +
                    rels.rule_14 + rels.rule_15 + rels.rule_19 + rels.rule_20 + rels.rule_21 + rels.rule_23 +
                    rels.rule_24 + rels.rule_25 + rels.rule_26 + rels.rule_27 + rels.rule_28 + rels.rule_29 +
                    rels.rule_30 + rels.rule_31 + rels.rule_32) over (partition by rels.rule_report) as rules_sum
                    ,case when rels.rule_29 = 1
                            or rels.rule_30 = 1
                            or rels.rule_31 = 1
                            or rels.rule_32 = 1 then '1' else '0' end as type_1
                    ,case when rels.rule_10 = 1
                            or rels.rule_11 = 1
                            or rels.rule_19 = 1
                            or rels.rule_20 = 1
                            or rels.rule_21 = 1 then '1' else '0' end as type_2
                    ,case when rels.rule_12 = 1 then '1' else '0' end as type_3
                    ,case when rels.rule_5 = 1 then '1' else '0' end as type_4
                    ,case when rels.rule_27 = 1
                            or rels.rule_28 = 1 then '1' else '0' end as type_5
                    ,case when rels.rule_23 = 1
                            or rels.rule_24 = 1
                            or rels.rule_25 = 1
                            or rels.rule_26 = 1 then '1' else '0' end as type_6
                    ,case when rels.rule_9 = 1 then '1' else '0' end as type_7
                    ,case when rels.rule_1 = 1
                            or rels.rule_2 = 1
                            or rels.rule_4 = 1
                            or rels.rule_6 = 1
                            or rels.rule_7 = 1 then '1' else '0' end as type_8
                    ,case when rels.rule_8 = 1
                            or rels.rule_13 = 1
                            or rels.rule_14 = 1
                            or rels.rule_15 = 1 then '1' else '0' end as type_9
    from rule_clcltr rels
)

,report_status as (
    select distinct report_040, insured_number, last_report_status, appllte_date
                    ,total_conclude_amount_a, total_conclude_amount_o, etl_upd_dttm
    from (
        select distinct aaa040.report_number as report_040
                        ,aaa040.insured_number
                        ,aaa040.insured_status as last_report_status
                        ,aaa040.appllte_date
                        ,sum(case
                            when aad011.afford_item = '1' then aad011.conclude_ntd_amount else 0 end)
                        over (partition by aad011.insured_number) as total_conclude_amount_a
                        ,sum(case
                            when aad011.afford_item <> '1' then aad011.conclude_ntd_amount else 0 end)
                        over (partition by aad011.insured_number) as total_conclude_amount_o
                        ,rank() over (partition by aaa040.insured_number order by aaa040.create_date_time desc) as insured_ranking
                        ,aaa040.etl_upd_dttm
        from cxi.dtaaa040 aaa040
        left join cxi.dtaad011 aad011
               on aaa040.insured_number = aad011.insured_number
              and aaa040.insured_sequence = aad011.insured_sequence
                  where 1 = 1
                    and aaa040.insured_number is not null
                    --and (aaa040.create_date >= '{data_date}' or aaa040.change_date >= '{data_date}')
                    and aaa040.product_policy_code in ('CF01001', 'CF01002')
                    and aad011.product_main_id not in ('CGB', 'CGA', 'CAL', 'C91', 'C92', 'C93', 'C94')
    ) tmp
    where insured_ranking = '1'
)

,aab011 as (
    select insured_number, last_forecast_amount
    from (
        select distinct aab011.insured_number
                        ,aab011.insured_sequence
                        ,sum(aab011.forecast_ntd_amount)
                            over (partition by aab011.insured_number, aab011.insured_sequence) as last_forecast_amount
                        ,rank() over (partition by aab011.insured_number order by aab011.insured_number, aab011.insured_sequence desc) as insured_ranking
        from cxi.dtaab011 aab011
            where 1 = 1
            and substr(aab011.product_main_id, 1, 1) = 'C'
            and aab011.product_main_id not in ('CGB', 'CGA', 'CAL', 'C91', 'C92', 'C93', 'C94')
        ) temp
            where insured_ranking = '1'
)
    
select distinct report_number
from (
    select distinct *
    from active_report
    left join report_status
      on active_report.insured_number = report_status.insured_number
    left join aab011
      on active_report.insured_number = aab011.insured_number
    left join rule_results
      on active_report.report_number = rule_results.rule_report
          where 1 = 1
            and active_report.pay_type is not null
             or active_report.insured_type is not null
             or active_report.apc_type is not null
) tmp
