with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)
                          
,aad017 as (
    select distinct insured_number
                    ,insured_sequence
                    ,certific_no as pay_id
    from cxi.dtaad017
        where 1 = 1
        and idntfctn_type not in ('4', '9')
        and substr(product_main_id, 1, 1) = 'C'
        and product_main_id not in ('CGB', 'CGA', 'CAL', 'C91', 'C92', 'C93', 'C94')
)

select distinct aaa040.report_number
                ,aad017.pay_id
from aaa040
left join aad017
       on aaa040.insured_number = aad017.insured_number
      and aaa040.insured_sequence = aad017.insured_sequence
