with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)

,aab024 as (
    select distinct insured_number
                    ,insured_sequence
                    ,oppsite_car_no
    from cxi.dtaab024
)

select distinct aaa040.report_number
                ,case
                    when aab024.oppsite_car_no not like '%-%' then '?'
                    when aab024.oppsite_car_no like '%-' then '?'
                    when aab024.oppsite_car_no like '-%' then '?'
                    when aab024.oppsite_car_no like '%*%' then '?'
                    when aab024.oppsite_car_no in ('-','X','XX','#','99999999','0','00','000','1','2','0-0',
                                                   '0-O','00-00','00-000','00-0000','000-00','000-0000', '0000-00',
                                                   '000-OOO','000-00','0000-000','0000-0000','000-000','000000') then '?'
                else trim(aab024.oppsite_car_no) end as oppsite_car_no
from aaa040
left join aab024
       on aaa040.insured_number = aab024.insured_number
      and aaa040.insured_sequence = aab024.insured_sequence
