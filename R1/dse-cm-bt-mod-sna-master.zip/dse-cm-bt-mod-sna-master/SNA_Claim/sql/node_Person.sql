with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)

,aab020 as (
    select distinct insured_number
                    ,insured_sequence
                    ,driver_customer_id
    from cxi.dtaab020
)

,aad017 as (
    select distinct insured_number
                    ,insured_sequence
                    ,certific_no as pay_id
    from cxi.dtaad017
        where 1 = 1
        and idntfctn_type not in ('4', '9')
        and substr(product_main_id, 1, 1) = 'C'
        and product_main_id not in ('CGB', 'CGA', 'CAL', 'C91', 'C92', 'C93', 'C94')
)

,abp001 as (
    select distinct contract_no
                    ,policy_no
    from cxi.dtabp001
        where 1 = 1
        and product_code = 'C'
        and account_date is not null
        and year(start_datetime) >= (year(current_date)-5)
)
                       
,abp004_ins as (
    select distinct contract_no
                    ,customer_id as insured_id
    from cxi.dtabp004
        where 1 = 1
        and customer_classfy = '2'
        and idntfctn_type not in ('4', '9')
)

,abp004_apc as (
    select distinct contract_no
                    ,customer_id as apc_id
    from cxi.dtabp004
        where 1 = 1
        and customer_classfy = '1'
        and idntfctn_type not in ('4', '9')
)

,aaa040_v2  as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,product_policy_code
                    ,appllte_date
                    ,create_date
                    ,change_date
                    ,etl_upd_dttm            
    from cxi.dtaaa040
)

,aab024_v2 as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,trim(oppsite_car_no) as oppsite_car_no
                    ,trim(opposite_name) as opposite_name
    from cxi.dtaab024
)

,aad017_v2 as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,certific_no
                    ,idntfctn_type
                    ,trim(customer_chinese_name) as customer_chinese_name
                    ,bank_account_head
                    ,bank_account
    from cxi.dtaad017
)

,clm_sna_abt as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct *
    from (
        select distinct aaa040_v2.*
                        ,aab024_v2.oppsite_car_no
                        ,aab024_v2.opposite_name
                        ,aad017_v2.certific_no
                        ,aad017_v2.idntfctn_type
                        ,aad017_v2.customer_chinese_name
                        ,aad017_v2.bank_account_head
                        ,aad017_v2.bank_account
                        ,case
                            when aab024_v2.opposite_name = aad017_v2.customer_chinese_name then '1'
                        else '0' end as op_is_pay                         
        from aaa040_v2
        left join aab024_v2
        on aaa040_v2.insured_number = aab024_v2.insured_number
        and aaa040_v2.insured_sequence = aab024_v2.insured_sequence
        left join aad017_v2
        on aaa040_v2.insured_number = aad017_v2.insured_number
        and aaa040_v2.insured_sequence = aad017_v2.insured_sequence
    ) temp
    where 1 = 1
    and insured_number is not null
    and product_policy_code in ('CF01001', 'CF01002')
    and to_date(etl_upd_dttm) >= date_sub(current_date(),1095)
)

,op2bank as (
    select distinct insured_number
                    ,insured_sequence
                    ,bank_account
    from clm_sna_abt
        where 1 = 1
          and op_is_pay = '1'
)

select distinct abp004_ins.insured_id as id
from aaa040
left join abp001
       on aaa040.policy_no = abp001.policy_no
left join abp004_ins
       on abp001.contract_no = abp004_ins.contract_no
union
select distinct abp004_apc.apc_id
from aaa040
left join abp001
       on aaa040.policy_no = abp001.policy_no
left join abp004_apc
       on abp001.contract_no = abp004_apc.contract_no
union
select distinct aab020.driver_customer_id
from aaa040
left join aab020
       on aaa040.insured_number = aab020.insured_number
      and aaa040.insured_sequence = aab020.insured_sequence
union
select distinct aad017.pay_id
from aaa040
left join aad017
       on aaa040.insured_number = aad017.insured_number
      and aaa040.insured_sequence = aad017.insured_sequence
union
select distinct op2bank.bank_account
from aaa040
left join op2bank
       on aaa040.insured_number = op2bank.insured_number
      and aaa040.insured_sequence = op2bank.insured_sequence
