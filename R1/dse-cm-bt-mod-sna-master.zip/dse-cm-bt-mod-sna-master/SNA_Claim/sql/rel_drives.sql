with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)
                          
,aab020 as (
    select distinct insured_number
                    ,insured_sequence
                    ,car_no
                    ,driver_customer_id
    from cxi.dtaab020
)

select distinct case
                    when aab020.car_no not like '%-%' then '?'
                    when aab020.car_no like '%-' then '?'
                    when aab020.car_no like '-%' then '?'
                    when aab020.car_no like '%*%' then '?'
                    when aab020.car_no in ('-','X','XX','#','99999999','0','00','000','1','2','0-0',
                                           '0-O','00-00','00-000','00-0000','000-00','000-0000','0000-00',
                                           '000-OOO','000-00','0000-000','0000-0000','000-000','000000') then '?'
                else aab020.driver_customer_id end as driver_customer_id
               ,case
                    when aab020.car_no not like '%-%' then '?'
                    when aab020.car_no like '%-' then '?'
                    when aab020.car_no like '-%' then '?'
                    when aab020.car_no like '%*%' then '?'
                    when aab020.car_no in ('-','X','XX','#','99999999','0','00','000','1','2','0-0',
                                           '0-O','00-00','00-000','00-0000','000-00','000-0000','0000-00',
                                           '000-OOO','000-00','0000-000','0000-0000','000-000','000000') then '?'
               else trim(aab020.car_no) end as car_no
from aaa040
left join aab020
       on aaa040.insured_number = aab020.insured_number
      and aaa040.insured_sequence = aab020.insured_sequence
