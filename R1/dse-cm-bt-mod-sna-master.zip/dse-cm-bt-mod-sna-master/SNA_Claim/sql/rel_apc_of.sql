with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)

,aab020 as (
    select distinct insured_number
                   ,insured_sequence
                   ,car_no
    from cxi.dtaab020
)

,abp001 as (
    select distinct contract_no
                   ,policy_no
    from cxi.dtabp001
       where 1 = 1
         and product_code = 'C'
         and account_date is not null
         and year(start_datetime) >= (year(current_date)-5)
)

,abp004_apc as (
    select distinct contract_no
                   ,customer_id as apc_id
    from cxi.dtabp004
       where 1 = 1
         and customer_classfy = '1'
         and idntfctn_type not in ('4', '9')
)

select distinct apc_id
                ,case
                    when aab020.car_no not like '%-%' then '?'
                    when aab020.car_no like '%-' then '?'
                    when aab020.car_no like '-%' then '?'
                    when aab020.car_no like '%*%' then '?'
                    when aab020.car_no in ('-','X','XX','#','99999999','0','00','000','1','2','0-0',
                                           '0-O','00-00','00-000','00-0000','000-00','000-0000','0000-00',
                                           '000-OOO','000-00','0000-000','0000-0000','000-000','000000') then '?'
                else trim(aab020.car_no) end as car_no
from aaa040
left join aab020
      on aaa040.insured_number = aab020.insured_number
     and aaa040.insured_sequence = aab020.insured_sequence
left join abp001
      on aaa040.policy_no = abp001.policy_no
left join abp004_apc
      on abp001.contract_no = abp004_apc.contract_no
