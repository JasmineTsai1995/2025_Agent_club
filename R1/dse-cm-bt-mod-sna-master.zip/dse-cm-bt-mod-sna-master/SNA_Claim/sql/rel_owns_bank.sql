with aaa040 as (
    select distinct report_number
                    ,insured_number
                    ,insured_sequence
                    ,policy_no
    from cxi.dtaaa040
        where 1 = 1
        and insured_number is not null
        and datediff(current_date, appllte_date) <= 1095
        and product_policy_code in ('CF01001', 'CF01002')
)

,dtaaa040_v2  as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,product_policy_code
                    ,appllte_date
                    ,create_date
                    ,change_date
                    ,etl_upd_dttm                           
    from cxi.dtaaa040
)

,dtaab024_v2 as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,trim(oppsite_car_no) as oppsite_car_no
                    ,trim(opposite_name) as opposite_name
    from cxi.dtaab024
)

,dtaad017_v2 as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct insured_number
                    ,insured_sequence
                    ,certific_no
                    ,idntfctn_type
                    ,trim(customer_chinese_name) as customer_chinese_name
                    ,bank_account_head
                    ,bank_account
    from cxi.dtaad017
)

,clm_sna_abt as ( --v2 add on 2024/11 from clm_sna_abt
    select distinct *
    from (
        select distinct aaa040_v2.*
                        ,aab024_v2.oppsite_car_no
                        ,aab024_v2.opposite_name
                        ,aad017_v2.certific_no
                        ,aad017_v2.idntfctn_type
                        ,aad017_v2.customer_chinese_name
                        ,aad017_v2.bank_account_head
                        ,aad017_v2.bank_account
                        ,case
                          when aab024_v2.opposite_name = aad017_v2.customer_chinese_name then '1'
                        else '0' end as op_is_pay                                 
        from aaa040_v2
        left join aab024_v2
        on aaa040_v2.insured_number = aab024_v2.insured_number
        and aaa040_v2.insured_sequence = aab024_v2.insured_sequence
        left join aad017_v2
        on aaa040_v2.insured_number = aad017_v2.insured_number
        and aaa040_v2.insured_sequence = aad017_v2.insured_sequence
    ) temp
    where 1 = 1
    and insured_number is not null
    and product_policy_code in ('CF01001', 'CF01002')
    and to_date(etl_upd_dttm) >= date_sub(current_date(),1095)
)

,op2bank as (
    select distinct insured_number
                    ,insured_sequence
                    ,oppsite_car_no
                    ,certific_no
                    ,bank_account
    from clm_sna_abt
        where 1 = 1
          and op_is_pay = '1'
)

select distinct case
                    when op2bank.oppsite_car_no not like '%-%' then '?'
                    when op2bank.oppsite_car_no like '%-' then '?'
                    when op2bank.oppsite_car_no like '-%' then '?'
                    when op2bank.oppsite_car_no like '%*%' then '?'
                    when op2bank.oppsite_car_no in ('-','X','XX','#','99999999','0','00','000','1','2','0-0',
                                                    '0-O','00-00','00-000','00-0000','000-00','000-0000', '0000-00',
                                                    '000-OOO','000-00','0000-000','0000-0000','000-000','000000') then '?'
                else trim(op2bank.oppsite_car_no) end as oppsite_car_no
                ,op2bank.bank_account
from aaa040
left join op2bank
       on aaa040.insured_number = op2bank.insured_number
      and aaa040.insured_sequence = op2bank.insured_sequence
    where 1 = 1
      and oppsite_car_no is not null