podman stop ${CI_PROJECT_NAME}
podman rm ${CI_PROJECT_NAME}
podman run -itd -e PIP_SERVER=${PIP_SERVER} \
-v /app/podman/${CI_PROJECT_NAME}-code:/project:z \
-v /mnt/DS_ftp/${CI_PROJECT_NAME}:/${CI_PROJECT_NAME} \
-p $2:8000 --name ${CI_PROJECT_NAME} ${CI_PROJECT_NAME}:$1
