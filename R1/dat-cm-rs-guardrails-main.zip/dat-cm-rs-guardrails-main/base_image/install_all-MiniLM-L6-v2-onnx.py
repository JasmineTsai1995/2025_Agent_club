import httpx
from huggingface_hub import set_client_factory, snapshot_download

set_client_factory(
    lambda: httpx.Client(
        verify=False,
        trust_env=True,
        follow_redirects=True,
        timeout=60,
    )
)

snapshot_download(
    repo_id="qdrant/all-MiniLM-L6-v2-onnx",
    repo_type="model",
    cache_dir="/opt/fastembed_cache",
    local_dir="/opt/fastembed_cache/qdrant/all-MiniLM-L6-v2-onnx",
    local_dir_use_symlinks=False,
)