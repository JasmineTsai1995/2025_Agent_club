mkdir -p /app/podman/${CI_PROJECT_NAME}/project
chmod -R 777 /app/podman/${CI_PROJECT_NAME}/project
podman stop --ignore ${CI_PROJECT_NAME}
podman rm --ignore ${CI_PROJECT_NAME}
podman rmi --ignore -f ${CI_PROJECT_NAME}:$1
podman build -t ${CI_PROJECT_NAME}:$1 --no-cache .
