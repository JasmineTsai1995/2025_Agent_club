import logging
from typing import Optional

from langchain_core.language_models.llms import BaseLLM

from nemoguardrails import RailsConfig
from nemoguardrails.actions.actions import action
from nemoguardrails.actions.llm.utils import llm_call
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.llm.taskmanager import LLMTaskManager
from nemoguardrails.llm.types import Task
from nemoguardrails.logging.explain import LLMCallInfo

from actions.utils import extract_user_message_content

log = logging.getLogger(__name__)


@action(execute_async=True)
async def self_check_input(
    llm_task_manager: LLMTaskManager,
    context: Optional[dict] = None,
    llm: Optional[BaseLLM] = None,
    config: Optional[RailsConfig] = None,
    is_explain: bool = False,
    **kwargs,
):
    """Checks the input from the user.

    Prompt the LLM, using the `check_input` task prompt, to determine if the input
    from the user should be allowed or not.

    Returns:
        True if the input should be allowed, False otherwise.
    """

    _DEFAULT_MAX_TOKENS = 4
    _EXPLAIN_MAX_TOKENS = 80
    user_input: str = extract_user_message_content(context)["text"]

    if not user_input or not user_input.strip():
        return {"allowed": True, "policy_violations": ""}

    task = Task.SELF_CHECK_INPUT
    prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={
            "user_input": user_input,
            "is_explain": is_explain,
        },
    )
    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task)
    
    if is_explain:
        max_tokens = max(max_tokens or _DEFAULT_MAX_TOKENS, _EXPLAIN_MAX_TOKENS)
    else: 
        max_tokens = max_tokens or _DEFAULT_MAX_TOKENS

    # Initialize the LLMCallInfo object
    llm_call_info_var.set(LLMCallInfo(task=task.value))

    result = await llm_call(
        llm,
        prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    log.info(f"Input self-checking result is: `{result}`.")

    result = llm_task_manager.parse_task_output(task, output=result)

    is_safe, *violated_policies = result

    final_result = {"allowed": is_safe, "policy_violations": violated_policies}
    log.info(final_result)
    return final_result

@action(execute_async=True)
async def self_check_output(
    llm_task_manager: LLMTaskManager,
    context: Optional[dict] = None,
    llm: Optional[BaseLLM] = None,
    config: Optional[RailsConfig] = None,
    is_explain: bool = False,
    **kwags,
):
    _DEFAULT_MAX_TOKENS = 4
    _EXPLAIN_MAX_TOKENS = 80

    bot_response = context.get("bot_message", "") if context else ""

    if not bot_response or not bot_response.strip():
        return {"allowed": True, "policy_violations": ""}
    
    task = Task.SELF_CHECK_OUTPUT
    prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={
            "bot_response": bot_response,
            "is_explain": is_explain,
        },
    )

    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task)

    if is_explain:
        max_tokens = max(max_tokens or _DEFAULT_MAX_TOKENS, _EXPLAIN_MAX_TOKENS)
    else:
        max_tokens = _DEFAULT_MAX_TOKENS
    
    llm_call_info_var.set(LLMCallInfo(task=task.value))

    result = await llm_call(
        llm,
        prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    log.info(f"Output self-checking result is: `{result}`.")

    result = llm_task_manager.parse_task_output(task, output=result)
    if_safe, *violated_policies = result

    final_result = {"allowed": if_safe, "policy_violations": violated_policies}
    log.info(final_result)
    return final_result