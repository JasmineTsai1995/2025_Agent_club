import logging
from typing import Any, Dict, Optional

from langchain_core.language_models import BaseLLM

from nemoguardrails.actions.actions import action
from nemoguardrails.actions.llm.utils import llm_call
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.llm.taskmanager import LLMTaskManager
from nemoguardrails.logging.explain import LLMCallInfo

from actions.utils import extract_user_message_content, replace_text_in_messages

log = logging.getLogger(__name__)


def _get_reasoning_enabled(llm_task_manager: LLMTaskManager) -> bool:
    return llm_task_manager.config.rails.config.content_safety.reasoning.enabled


def _format_multimodal_user_input(user_message: Any) -> Any:
    parsed = extract_user_message_content({"user_message": user_message})
    text = parsed["text"]

    if not parsed["has_text"] or not text.strip():
        return user_message

    return replace_text_in_messages(user_message, f"待檢查訊息如下:\n「{text}」")


@action()
async def self_multimodal_check_input(
    llms: Dict[str, BaseLLM],
    llm_task_manager: LLMTaskManager,
    model_name: Optional[str] = None,
    context: Optional[dict] = None,
    is_explain: bool = False,
    **kwargs,
) -> dict: 
    _DEFAULT_MAX_TOKENS = 4
    _EXPLAIN_MAX_TOKENS = 80
    user_input: Any = ""

    if not extract_user_message_content(context)["has_image"]:
        return {"allowed": True, "policy_violations": ""}

    if context is not None:
        user_input = context.get("user_message", "")
        model_name = model_name or context.get("model", None)
        user_input = _format_multimodal_user_input(user_input)

    if model_name is None:
        error_msg = (
            "Model name is required for content safety check, "
            "please provide it as an argument in the config.yml. "
            "e.g. content safety check input $model=llama_guard"
        )
        raise ValueError(error_msg)

    llm = llms.get(model_name, None)

    if llm is None:
        error_msg = (
            f"Model {model_name} not found in the list of available models for content safety check. "
            "Please provide a valid model name."
        )
        raise ValueError(error_msg)

    explain = _get_reasoning_enabled(llm_task_manager) or is_explain
    task = f"self_multimodal_check_input $model={model_name}"
    check_input_prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={
            "user_input": user_input,
            "reasoning_enabled": explain,
            "is_explain": explain,
        },
    )
    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task)

    if explain:
        max_tokens = max(max_tokens or _DEFAULT_MAX_TOKENS, _EXPLAIN_MAX_TOKENS)
    else:
        max_tokens = _DEFAULT_MAX_TOKENS

    # Initialize the LLMCallInfo object
    llm_call_info_var.set(LLMCallInfo(task=task))

    result = await llm_call(
        llm,
        check_input_prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    result = llm_task_manager.parse_task_output(task, output=result)

    is_safe, *violated_policies = result

    final_result = {"allowed": is_safe, "policy_violations": violated_policies}
    log.info(final_result)
    return final_result

@action()
async def self_multimodal_check_output(
    llms: Dict[str, BaseLLM],
    llm_task_manager: LLMTaskManager,
    model_name: Optional[str] = None,
    context: Optional[dict] = None,
    is_explain: bool = False,
    **kwargs,
) -> dict:
    _DEFAULT_MAX_TOKENS = 4
    _EXPLAIN_MAX_TOKENS = 80

    user_input: Any = ""
    bot_response: Any = ""

    if context is not None:
        user_input = context.get("user_message", "")
        bot_response = context.get("bot_message", "")
        model_name = model_name or context.get("model", None)
    
    if not bot_response or not str(bot_response).strip():
        return {"allowed": True, "policy_violations": ""}
    
    if model_name is None:
        raise ValueError(
            "Model name is required for content safety check output. "
            "Please provide it as an argument in config.yml."
        )
    
    llm = llms.get(model_name, None)

    if llm is None:
        raise ValueError(f"Model {model_name} not found.")
    
    explain = _get_reasoning_enabled(llm_task_manager) or is_explain
    task = f"self_multimodal_check_output $model={model_name}"
    check_output_prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={
            "user_input": user_input,
            "bot_response": bot_response,
            "is_explain": explain,
        },
    )

    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task)

    if explain:
        max_tokens = max(max_tokens or _DEFAULT_MAX_TOKENS, _EXPLAIN_MAX_TOKENS)
    else:
        max_tokens = _DEFAULT_MAX_TOKENS

    llm_call_info_var.set(LLMCallInfo(task=task))

    result = await llm_call(
        llm,
        check_output_prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    log.info(f"Multimodal output self-checking result is: `{result}`.")

    result = llm_task_manager.parse_task_output(task, output=result)
    is_safe, *violated_policies = result
    
    final_result = {"allowed": is_safe, "policy_violations": violated_policies}
    log.info(final_result)
    return final_result