import re
import os
import json
import inspect
from functools import lru_cache
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

from nemoguardrails import RailsConfig
from nemoguardrails.actions import action
from nemoguardrails.actions.llm.utils import llm_call
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.llm.taskmanager import LLMTaskManager
from nemoguardrails.logging.explain import LLMCallInfo

from langchain_core.language_models.llms import BaseLLM
from presidio_analyzer import RecognizerRegistry, AnalyzerEngine, Pattern, PatternRecognizer, RecognizerResult
from presidio_analyzer.nlp_engine import NlpEngineProvider, NlpArtifacts
from presidio_anonymizer import AnonymizerEngine
from presidio_analyzer.predefined_recognizers import PhoneRecognizer, CreditCardRecognizer, EmailRecognizer, DateRecognizer

from actions.utils import extract_user_message_content, replace_text_in_messages

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)


@dataclass
class ContextConfig:
    window_size: int = 10
    scores: Dict[str, float] = None
    before_weight: float = 1.1
    after_weight: float = 1.0

    def __post_init__(self):
        # 定義不同上下文的信心分數
        if not self.scores:
            self.scores = {
                'high_confidence': 0.9,
                'medium_confidence': 0.7,
                'weak_confidence': 0.5,
            }


class ContextAwareRecognizerMixin:
    def __init__(
        self,
        context_words: Dict[str, List[str]],
        config: Optional[ContextConfig] = None
    ):
        self.config = config or ContextConfig()
        self.compiled_contexts = {
            confidence: [
                re.compile(pattern, re.IGNORECASE)
                for pattern in patterns
            ]
            for confidence, patterns in context_words.items()
        }

    def check_context(self, text: str, start: int, end: int) -> float:
        """
        檢查上下文並返回信心分數
        :param text: 完整文本
        :param start: 匹配開始位置
        :param end: 匹配結束位置
        :return: 信心分數 (0.0 - 1.0)
        """
        if not text or start < 0 or end > len(text) or start >= end:
            return 0.0

        # 計算上下文範圍
        context_start = max(0, start - self.config.window_size)
        context_end = min(len(text), end + self.config.window_size)
        before_context = text[context_start:start]
        after_context = text[end:context_end]

        # 檢查關鍵字出現的位置，並計算對應的信心分數
        best_score = 0.0
        for context_type, patterns in self.compiled_contexts.items():
            base_score = self.config.scores[context_type]
            best_score = max(
                best_score,
                self._check_direction(patterns, before_context, base_score, self.config.before_weight),
                self._check_direction(patterns, after_context, base_score, self.config.after_weight)
            )

        return best_score

    def _check_direction(
        self,
        patterns: List[Pattern],
        context: str,
        base_score: float,
        weight: float
    ) -> float:
        """
        檢查上下文是否含有對應 pattern, 並返回信心分數(score = 基底分數 * 關鍵字距離 * 上下文權重)

        :param patterns: 檢查的pattern
        :param context: 待檢查的上下文
        :param base_score: pattern對應的基底分數
        :param weight: 上下文權重
        :return: 信心分數 (0.0 - 1.0)
        """
        best_score = 0.0
        for pattern in patterns:
            matches = list(pattern.finditer(context))
            for match in matches:
                if weight == self.config.before_weight:
                    # 上文檢查：計算關鍵字結束位置到 Pattern 開始位置的距離
                    distance = len(context) - match.end()
                else:
                    # 下文檢查：計算 Pattern 結束位置到關鍵字開始位置的距離
                    distance = match.start()
                distance_factor = max(0, 1 - (distance / self.config.window_size))
                current_score = base_score * distance_factor * weight
                best_score = max(best_score, current_score)
        return best_score

    def apply_context_filter(
        self, 
        text: str, 
        results: List[RecognizerResult]
    ) -> List[RecognizerResult]:
        filtered = []
        for result in results:
            context_score = self.check_context(text, result.start, result.end)
            if context_score > 0:
                result.score = context_score
                filtered.append(result)
        return filtered


class TaiwanIDRecognizer(PatternRecognizer, ContextAwareRecognizerMixin):

    CONTEXT_WORDS = {
        'high_confidence': [r'身[份分]證(?:字號|號碼|號)', r'id\s*number', r'identification\s*number'],
        'medium_confidence': [r'(?:國民)?身[分份]證(?:件|明)?', r'id', r'identification', r'證(?:件號碼|號)'],
        'weak_confidence': [r'號碼']
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        patterns = [Pattern(name="taiwan_id", regex=r"[A-Z][12]\d{8}", score=0.8)]

        PatternRecognizer.__init__(
            self,
            supported_entity="PERSONAL_ID",
            patterns=patterns,
            context=context,
            supported_language=supported_language
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )
    
    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)

        if results:
            results = self.apply_context_filter(text, results)
        return results


class TaiwanARCRecognizer(PatternRecognizer, ContextAwareRecognizerMixin):

    CONTEXT_WORDS = {
        'high_confidence': [r'居留證號[碼]?', r'統一證號', r'ARC\s*number', r'居留證', r'Alien\s*Resident\s*Certificate'],
        'medium_confidence': [r'居留', r'ARC', r'統一證', r'證(?:件號碼|號)'],
        'weak_confidence': [r'號碼']
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        patterns = [
            Pattern(name="taiwan_arc_new", regex=r"[A-Z][8,9]\d{8}", score=0.8),
            Pattern(name="taiwan_arc_old", regex=r"[A-Z][A,B,C,D][0-9]{8}", score=0.8),
        ]

        PatternRecognizer.__init__(
            self,
            supported_entity="ARC_ID",
            patterns=patterns,
            context=context,
            supported_language=supported_language
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )
    
    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)

        if results:
            results = self.apply_context_filter(text, results)
        return results


class TaiwanPassportRecognizer(PatternRecognizer, ContextAwareRecognizerMixin):

    CONTEXT_WORDS = {
        'high_confidence': [r'護照號[碼]?', r'passport\s*number'],
        'medium_confidence': [r'護照', r'passport'],
        'weak_confidence': [r'旅行證件', r'travel\s+document', r'簽證', r'visa', r'入境', r'出境']
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        patterns = [Pattern(name="tw_passport", regex=r"\d{9}", score=0.5)]

        PatternRecognizer.__init__(
            self,
            supported_entity="PASSPORT_NUMBER",
            patterns=patterns,
            context=context,
            supported_language=supported_language
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )
    
    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)
        if results:
            results = self.apply_context_filter(text, results)
        return results


class AgeRecognizer(PatternRecognizer, ContextAwareRecognizerMixin):

    CONTEXT_WORDS = {
        'high_confidence': [r'年[齡紀]', r'age', r'years?\s*old'],
        'medium_confidence': [r'幾歲', r'歲', r'年滿'],
        'weak_confidence': [r'出生[年月日]*']
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        patterns = [
            Pattern(name="age_numeric_strict", regex=r"(0|[1-9]\d?|1[0-4]\d|150)", score=0.9),
        ]

        PatternRecognizer.__init__(
            self,
            supported_entity="AGE",
            patterns=patterns,
            context=context,
            supported_language=supported_language
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )
    
    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)

        if results:
            results = self.apply_context_filter(text, results)
        return results


class TaiwanPhoneRecognizer(PhoneRecognizer, ContextAwareRecognizerMixin):

    DEFAULT_CONTEXT = [
        "電話", "市話", "行動電話", "手機", "電話號碼",
        "phone", "number", "telephone", "cell", "cellphone", "mobile", "call"
    ]
    CONTEXT_WORDS = {
        'high_confidence': [
            r'電話號[碼]?', r'行動電話', r'手機號[碼]?', 
            r'contact\s*(number|phone)', r'phone\s*(number|no\.?)', 
            r'mobile\s*(number|phone)'
        ],
        'medium_confidence': [
            r'電話', r'手機', r'聯絡方式', r'聯絡電話', r'通訊方式',
            r'call\s*(me|number)', r'reach\s*(me|out|number)'
        ],
        'weak_confidence': [
            r'聯絡', r'通話', r'資訊', r'號碼', r'撥打', 
            r'message\s*me', r'text\s*(me|number)'
        ]
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        leniency: Optional[int] = 1,
        supported_language: str = "zh"
    ):
        PhoneRecognizer.__init__(
            self,
            leniency=leniency,
            context=self.DEFAULT_CONTEXT,
            supported_language=supported_language,
            supported_regions={"US", "UK", "DE", "FE", "IL", "IN", "CA", "BR", "TW"},
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )
    
    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)
        if results:
            results = self.apply_context_filter(text, results)
        return results


class BirthdayRecognizer(DateRecognizer, ContextAwareRecognizerMixin):

    TAIWAN_DATE_PATTERNS = [
        # 西元 with 年月日
        Pattern(
            name="ce_year_chinese_notation",
            regex=r"(?:\d{4}\s*年\s*)?([1-9]|0[1-9]|1[0-2])\s*月\s*([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\s*日",
            score=0.8
        ),
        # 民國 with 年月日 (traditional Chinese notation)
        Pattern(
            name="taiwan_year_chinese_notation",
            regex=r"(?:\d{2,3}\s*年\s*)?([1-9]|0[1-9]|1[0-2])\s*月\s*([1-9]|0[1-9]|[1-2][0-9]|3[0-1])\s*日",
            score=0.8
        ),
        # 民國年/月/日 (with slashes)
        Pattern(
            name="taiwan_year_slash",
            regex=r"(?:\d{2,3}/)?([1-9]|0[1-9]|1[0-2])/([1-9]|0[1-9]|[1-2][0-9]|3[0-1])",
            score=0.7
        ),
        # 民國年-月-日 (with hyphens)
        Pattern(
            name="taiwan_year_hyphen",
            regex=r"(?:\d{2,3}-)?([1-9]|0[1-9]|1[0-2])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])",
            score=0.7
        ),
        # 民國年.月.日 (with dot)
        Pattern(
            name="taiwan_year_dot",
            regex=r"(?:\d{2,3}\.)?([1-9]|0[1-9]|1[0-2])\.([1-9]|0[1-9]|[1-2][0-9]|3[0-1])",
            score=0.6
        )
    ]

    CONTEXT_WORDS = {
        'high_confidence': [r'生日', r'出生日期', r'birthday', r'date of birth', r'出生年月日'],
        'medium_confidence': [r'年齡', r'出生', r'年紀']
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        self.__modify_default_pattern()
        combined_patterns = self.PATTERNS + self.TAIWAN_DATE_PATTERNS

        DateRecognizer.__init__(
            self,
            patterns=combined_patterns,
            context=context or self.CONTEXT,
            supported_language="zh",
            supported_entity="DATE_TIME"
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config or ContextConfig()
        )

    def __modify_default_pattern(self):
        for pattern in self.PATTERNS:
            pattern.regex = pattern.regex.replace(r'\b', '')

    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)
        if results:
            results = self.apply_context_filter(text, results)
        return results


class AddressRecognizer(PatternRecognizer, ContextAwareRecognizerMixin):

    CONTEXT_WORDS = {
        'high_confidence': [
            r'住址', r'地址', r'居住', r'通訊地址', r'郵(?:編|遞區號)',
            r'\bAddress\b', r'(Residential|Mailing|Postal)\s*Address'
        ],
        'medium_confidence': [
            r'所在(?:位置|地區)?', '住在', r'所在地', r'located\s+(?:at|in)', r'\blocation\b'
        ],
    }

    def __init__(
        self,
        context: Optional[List[str]] = None,
        config: Optional[ContextConfig] = None,
        supported_language: str = "zh"
    ):
        patterns = [
            Pattern(
                name="chinese_address", 
                regex=\
                    r"([\u4e00-\u9fa5A-Za-z]{2}(?:縣|市))" \
                    r"([\u4e00-\u9fa5A-Za-z]{1,3}(?:鄉|鎮|市|區))?" \
                    r"([\u4e00-\u9fa5A-Za-z]{1,5}(?:村|里))?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,5}鄰)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,5}(?:路|街|大道))?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}段)?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[巷])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[弄])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)(?:[之-](?:[一二三四五六七八九十百千兩零]+|\d+))?號)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}(?:樓|F))?" \
                    r"(?:[之-][\u4e00-\u9fa5A-Za-z0-9]+)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]+室)?",
                score=0.8
            ),
            Pattern(
                name="chinese_county_address", 
                regex=\
                    r"([\u4e00-\u9fa5A-Za-z]{1,3}(?:鄉|鎮|市|區))" \
                    r"([\u4e00-\u9fa5A-Za-z]{1,5}(?:村|里))?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,5}鄰)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,5}(?:路|街|大道))?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}段)?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[巷])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[弄])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)(?:[之-](?:[一二三四五六七八九十百千兩零]+|\d+))?號)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}(?:樓|F))?" \
                    r"(?:[之-][\u4e00-\u9fa5A-Za-z0-9]+)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]+室)?",
                score=0.7
            ),
            Pattern(
                name="chinese_road_address", 
                regex=\
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,5}(?:路|街|大道))" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}段)?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[巷])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)[弄])?" \
                    r"((?:[一二三四五六七八九十百千兩零]+|\d+)(?:[之-](?:[一二三四五六七八九十百千兩零]+|\d+))?號)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]{1,3}(?:樓|F))?" \
                    r"(?:[之-][\u4e00-\u9fa5A-Za-z0-9]+)?" \
                    r"([\u4e00-\u9fa5A-Za-z0-9]+室)?",
                score=0.7
            ),
            Pattern(
                name="english_address", 
                regex=\
                    r"(?P<street>[a-zA-Z0-9_\s\.,'-]+)" \
                    r"(?:,\s*(?P<city>[a-zA-Z0-9_\s\.,'-]+))?" \
                    r"(?:,\s*(?P<region>[a-zA-Z0-9_\s\.,'-]+))? " \
                    r"(?:,\s*(?P<postal>[a-zA-Z0-9_\s\.-]+))?" \
                    r"(?:,\s*(?P<country>[a-zA-Z0-9_\s\.,'-]+))?",
                score=0.8
            )
        ]

        PatternRecognizer.__init__(
            self,
            supported_entity="ADDRESS",
            patterns=patterns,
            context=context,
            supported_language=supported_language
        )

        ContextAwareRecognizerMixin.__init__(
            self,
            context_words=self.CONTEXT_WORDS,
            config=config
        )

    def analyze(
        self,
        text: str,
        entities: List[str],
        nlp_artifacts: Optional[NlpArtifacts] = None
    ) -> List[RecognizerResult]:
        results = super().analyze(text, entities, nlp_artifacts)
        if results:
            results = self.apply_context_filter(text, results)
        return results


@dataclass
class EntityConfig:
    name: str
    description: str
    recognizer: object


class EntityConfigManager:
    ENTITY_CONFIGS: Dict[str, EntityConfig] = {
        "NAME": EntityConfig(
            name="姓名",
            description="完整或部分個人姓名，包括全名、姓氏或名字",
            recognizer=None
        ),
        "ADDRESS": EntityConfig(
            name="住址/出生地",
            description="具體居住地址或出生地點，包括完整或部分地址，如城市、區域、街道、門牌等",
            recognizer=AddressRecognizer
        ),
        "DATE_TIME": EntityConfig(
            name="生日",
            description="個人出生日期，可為多種日期格式",
            recognizer=BirthdayRecognizer
        ),
        "PHONE_NUMBER": EntityConfig(
            name="電話",
            description="個人聯絡電話號碼，包括市話、手機號碼",
            recognizer=TaiwanPhoneRecognizer
        ),
        "PASSPORT_NUMBER": EntityConfig(
            name="護照號碼",
            description="國際旅行證件唯一識別號碼",
            recognizer=TaiwanPassportRecognizer
        ),
        "PERSONAL_ID": EntityConfig(
            name="身分證字號",
            description="國民身分識別碼，唯一辨識個人身份",
            recognizer=TaiwanIDRecognizer
        ),
        "ARC_ID": EntityConfig(
            name="居留證號碼",
            description="外籍人士在當地的居留證件號碼",
            recognizer=TaiwanARCRecognizer
        ),
        "CREDIT_CARD": EntityConfig(
            name="信用卡號碼",
            description="銀行發行的信用卡唯一識別碼",
            recognizer=CreditCardRecognizer
        ),
        "EMAIL": EntityConfig(
            name="E-Mail",
            description="個人電子郵件地址",
            recognizer=EmailRecognizer
        ),
        "ACCOUNT_PWD": EntityConfig(
            name="帳號密碼",
            description="系統登入憑證組合",
            recognizer=None
        ),
        "AGE": EntityConfig(
            name="年齡",
            description="個人年齡數值",
            recognizer=AgeRecognizer
        )
    }

    @classmethod
    def validate_entities(cls, entities: List[str]) -> None:
        valid_keys = cls.ENTITY_CONFIGS.keys()
        undefined_entities = [x for x in entities if x.upper() not in valid_keys]
        
        if undefined_entities:
            raise ValueError(f"You provided invalid entity names: {undefined_entities}")

    @classmethod
    def get_recognizer(cls, entity_key: str) -> object:
        return cls.ENTITY_CONFIGS[entity_key.upper()].recognizer

    @classmethod
    def generate_entities_text(cls, entities: List[str]) -> str:
        entity_lines = (
            f"  {cls.ENTITY_CONFIGS[key].name}\n"
            f"  - ENTITY KEY: {key}\n"
            f"  - 說明: {cls.ENTITY_CONFIGS[key].description}"
            for key in sorted(entities)
        )
        return '\n\n'.join(entity_lines)


class RegexPiiDetector:
    def __init__(self, entities: List[str], language: str = "zh"):
        EntityConfigManager.validate_entities(entities)
        
        # Standardize entity names to uppercase and sort them for caching purposes
        self.entities: Tuple[str, ...] = tuple(sorted(entity.upper() for entity in entities))
        self.language = language

        # Retrieve the analyzer engine from cache
        self.analyzer_engine = self._create_analyzer_engine(self.entities, self.language)
        self.anonymizer_engine = AnonymizerEngine()

    def detect_pii(self, original_text: str) -> str:
        """Detects and anonymizes PII within the provided text using regex-based analysis."""
        analyzer_results = self.analyzer_engine.analyze(
            text=original_text,
            language=self.language
        )
        anonymized_result = self.anonymizer_engine.anonymize(
            text=original_text,
            analyzer_results=analyzer_results
        )
        return anonymized_result.text

    @classmethod
    @lru_cache(maxsize=6)
    def _create_nlp_engine(cls, language: str = "zh"):
        """
        Loads and caches the NLP engine (using spaCy).
        This example uses the Chinese model "zh_core_web_lg". Ensure that it is installed.
        """
        import spacy
        if not spacy.util.is_package("zh_core_web_lg"):
            raise RuntimeError("The zh_core_web_lg model cannot be found. Please install it via: python -m spacy download zh_core_web_lg")

        configuration = {
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": language, "model_name": f"{language}_core_web_lg"}]
        }
        provider = NlpEngineProvider(nlp_configuration=configuration)
        return provider.create_engine()

    @classmethod
    @lru_cache(maxsize=6)
    def _create_analyzer_engine(cls, entities: Tuple[str, ...], language: str = "zh"):
        """
        Creates and caches an AnalyzerEngine based on the provided entities and language.
        Since the entities parameter is a tuple (and therefore hashable), it can be used as the cache key.
        """
        registry = RecognizerRegistry(supported_languages=language)
        
        for entity in entities:
            if recognizer_cls := EntityConfigManager.get_recognizer(entity):
                registry.add_recognizer(recognizer_cls(supported_language=language))
        
        return AnalyzerEngine(
            registry=registry,
            nlp_engine=cls._create_nlp_engine(language),
            supported_languages=language
        )


class LLMPIIDetector:   
    def __init__(
        self,
        task: str,
        entities: List[str],
        llm_task_manager: LLMTaskManager,
        llm: Optional[BaseLLM],
    ):
        EntityConfigManager.validate_entities(entities)
        self.entities: Tuple[str, ...] = tuple(sorted(entity.upper() for entity in entities))
        self.entities_text = EntityConfigManager.generate_entities_text(self.entities)

        self.task = task
        self.llm = llm
        self.llm_task_manager = llm_task_manager

    async def detect_pii(self, text: str, max_tokens: int) -> str:
        # (1) Getting prompt
        prompt_context = {
            "entities_text": self.entities_text,
            "pre_masked_text": text}
        prompt = self.llm_task_manager.render_task_prompt(task=self.task, context=prompt_context)
        stop = self.llm_task_manager.get_stop_tokens(task=self.task)

        # (2) Initialize the LLMCallInfo object
        llm_call_info_var.set(LLMCallInfo(task=self.task))

        # (3) LLM judge the text
        response = await llm_call(
            self.llm,
            prompt,
            stop=stop,
            llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
        )
        
        return response.strip()

    def parse_task_output(self, response: str) -> str:
        pattern = re.compile(r'```(.*?)```', re.DOTALL)
        match = pattern.search(response)
        if match:
            return match.group(1).strip()
        return response


@action(execute_async=False)
async def check_personal_info(
    is_masked: bool,
    is_input: bool,
    llm_task_manager: LLMTaskManager,
    use_llm: bool = True,
    context: Optional[dict] = None,
    llm: Optional[BaseLLM] = None,
    config: Optional[RailsConfig] = None,
):
    """Checks the facts for the bot response by appropriately prompting the base llm."""

    message_key = "user_message" if is_input else "bot_message"
    message_payload = context.get(message_key, "")
    input_text = extract_user_message_content({"user_message": message_payload})["text"]

    if not input_text or not input_text.strip():
        return message_payload if is_masked else False

    task_prefix = "mask" if is_masked else "detect"
    task_suffix = "input" if is_input else "output"
    task = task_prefix + "_personal_info_on_" + task_suffix
    max_tokens = 5000 if is_masked else 3

    with open(f'{parent_dir}/project_config.json') as json_file:
        project_config = json.load(json_file)

    function_name = inspect.currentframe().f_code.co_name
    if function_name in project_config:
        entities = project_config[function_name]['blocked']
    else:
        entities = [
            "NAME", "ADDRESS", "DATE_TIME", "PHONE_NUMBER", "PASSPORT_NUMBER",
            "PERSONAL_ID", "ARC_ID", "CREDIT_CARD", "EMAIL", "ACCOUNT_PWD",
            "AGE",
        ]

    # Rule Based
    regex_detector = RegexPiiDetector(entities)
    pre_masked_text = regex_detector.detect_pii(input_text)

    if is_masked and not use_llm:
        return replace_text_in_messages(message_payload, pre_masked_text)

    # LLM Based
    llm_detector = LLMPIIDetector(
        task=task,
        entities=entities,
        llm_task_manager=llm_task_manager,
        llm=llm)
    response = await llm_detector.detect_pii(
        text=pre_masked_text,
        max_tokens=max_tokens)

    if is_masked:
        if "No" in response:
            masked_text = pre_masked_text
        else:
            masked_text = llm_detector.parse_task_output(response)

        return replace_text_in_messages(message_payload, masked_text)

    has_sensitive_data = not ("No" in response[:5] and input_text == pre_masked_text)
    return has_sensitive_data
