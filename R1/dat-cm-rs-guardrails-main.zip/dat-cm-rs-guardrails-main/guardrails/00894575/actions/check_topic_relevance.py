import os
import json
import logging
import inspect
from typing import Optional, List

from langchain_core.language_models.llms import BaseLLM

from nemoguardrails import RailsConfig
from nemoguardrails.actions import action
from nemoguardrails.actions.llm.utils import llm_call
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.llm.taskmanager import LLMTaskManager
from nemoguardrails.logging.explain import LLMCallInfo

from actions.utils import extract_user_message_content

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
log = logging.getLogger(__name__)


@action(execute_async=True)
async def check_topic_relevance(
    llm_task_manager: LLMTaskManager,
    context: Optional[dict] = None,
    llm: Optional[BaseLLM] = None,
    config: Optional[RailsConfig] = None,
    is_explain: bool = False
):
    """Checks the facts for the bot response by appropriately prompting the base llm."""

    _MAX_TOKEN = 4
    user_input: str = extract_user_message_content(context)["text"]

    if not user_input or not user_input.strip():
        return {"allowed": True, "policy_violations": ""}

    # Getting the parameter of prompt
    task = inspect.stack()[0].function
    prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={"user_input": user_input})
    stop = llm_task_manager.get_stop_tokens(task=task)

    if is_explain:
        max_tokens = max(_MAX_TOKEN, 5000)
    else:
        max_tokens = llm_task_manager.get_max_tokens(task=task) or _MAX_TOKEN 

    # Initialize the LLMCallInfo object
    llm_call_info_var.set(LLMCallInfo(task=task))

    # LLM judge whether the response is relevant to topic
    result = await llm_call(
        llm,
        prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    # The result of parser: True("safe", "no" - is_blocked); False("unsafe", "yes")
    result = llm_task_manager.parse_task_output(task, output=result)

    is_safe, *violated_policies = result

    final_result = {"allowed": is_safe, "policy_violations": violated_policies}
    log.info(final_result)
    return final_result


@action(execute_async=True)
async def check_topic_relevance_context(
    llm_task_manager: LLMTaskManager,
    context: dict | None = None,
    llm: BaseLLM | None = None,
    config: RailsConfig | None = None,
    events: List[dict] | None = None,
    is_explain: bool = False,
):
    """Checks the facts for the bot response by appropriately prompting the base llm."""

    with open(f'{parent_dir}/project_config.json') as json_file:
        project_config = json.load(json_file)

    task = inspect.stack()[0].function
    _MAX_TOKEN = 4
    N_CONTEXT = project_config[task]["n_context"]
    user_input: str = extract_user_message_content(context)["text"]

    if not user_input or not user_input.strip():
        return {"allowed": True, "policy_violations": "", "n_context": str(N_CONTEXT)}

    chat_history = events_to_chat_history(events)   
    chat_history_string = chat_history_render(chat_history, N_CONTEXT)

    # Getting the parameter of prompt
    prompt = llm_task_manager.render_task_prompt(
        task=task,
        context={
            "user_input": user_input,
            "last_n_history_context": N_CONTEXT - 1, # remove the user intput
            "chat_history_string": chat_history_string}
    )
    
    stop = llm_task_manager.get_stop_tokens(task=task)

    if is_explain:
        max_tokens = max(_MAX_TOKEN, 1000)
    else:
        max_tokens = llm_task_manager.get_max_tokens(task=task) or _MAX_TOKEN 

    # Initialize the LLMCallInfo object
    llm_call_info_var.set(LLMCallInfo(task=task))

    # LLM judge whether the response is relevant to topic
    result = await llm_call(
        llm,
        prompt,
        stop=stop,
        llm_params={"temperature": 1e-20, "max_tokens": max_tokens},
    )

    # The result of parser: True("safe", "no" - is_blocked); False("unsafe", "yes")
    result = llm_task_manager.parse_task_output(task, output=result)

    is_safe, *violated_policies = result

    final_result = {
        "allowed": is_safe,
        "policy_violations": violated_policies,
        "n_context": str(N_CONTEXT),
    }
    log.info(final_result)
    return final_result


def events_to_chat_history(events: List[dict] | None) -> List[dict]:

    USER_MESSAGE_EVENTNAME = "UtteranceUserActionFinished"
    BOT_MESSAGE_EVENTNAME = "UtteranceBotActionFinished"

    try:
        if not events:
            raise ValueError("events list is empty or None.")

        chat_history = []
        for e in events:
            event_type = e.get("type")
            if event_type == USER_MESSAGE_EVENTNAME:
                chat_history.append({"role": "user", "content": e.get("final_transcript", "")})
            elif event_type == BOT_MESSAGE_EVENTNAME:
                chat_history.append({"role": "assistant", "content": e.get("final_script", "")})

        return chat_history

    except Exception as e:
        log.exception("Error extract conversation history")
        return []


def chat_history_render(
        chat_history: List[dict] | None = None,
        n_context: int | None = None
    ) -> str:
    try:
        if chat_history is None:
            raise ValueError("chat_history is required and cannot be None.")
        if not isinstance(n_context, int) or n_context < 2:
            raise ValueError("n_context must be an integer greater than or equal to 2.")

        # 取最後 n_context-1 筆（排除最後一筆）
        chat_history = chat_history[-n_context:-1]

        lines = [
            f"{entry['role']}: {entry['content']}"
            for entry in chat_history
        ]
        history_prompt = "\n".join(lines)
        return history_prompt

    except Exception:
        log.exception("Error render conversation history")
        return ""
