from typing import Any, List, Tuple, Dict


def _parse_user_message_content(user_message: Any) -> Tuple[str, bool, bool]:
    """
    Normalize a Guardrails/OpenAI-style user message into:
    1. a plain text string and
    2. a boolean flag indicating whether any text block is present and
    3. a boolean flag indicating whether any image block is present.

    Why this exists:
    - Some Nemo Guardrails rails are text-only and should receive only text.
    - Some rails (for example vision rails) need multimodal context and must
      know whether images are included.

    Supported input shapes:
    - `str`: treated as plain text, `has_text=True` when non-empty,
      `has_image=False`.
    - `list[dict]`: OpenAI-style content blocks where text is collected from
      blocks with `type="text"` and image presence is detected from
      `type in {"image_url", "image"}` (or equivalent keys).
        {
            "role": "user",
            "content": [
                {"type": "text", "text": content},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
            ]
        }
    - any other type: converted to string as a safe fallback.

    Args:
        user_message: A user payload from Guardrails context. Supported shapes
          include plain text (`str`), OpenAI-style content blocks
          (`list[dict]`), or any fallback type.

    Returns:
        A tuple `(text, has_text, has_image)` where:
        - `text` is the extracted plain text for text-only rails.
        - `has_text` indicates whether any text input exists.
        - `has_image` indicates whether any image block is present.
    """
    if user_message is None:
        return "", False, False

    # pure text input
    if isinstance(user_message, str):
        return user_message, bool(user_message.strip()), False

    # OpenAI-style content blocks
    if isinstance(user_message, list):
        text_parts: List[str] = []
        has_text = False
        has_image = False

        for blk in user_message:
            if not isinstance(blk, dict):
                continue

            btype = blk.get("type")

            if btype == "text":
                has_text = True
                t = blk.get("text", "")
                if isinstance(t, str) and t.strip():
                    text_parts.append(t)
            elif btype =="image_url":
                # OpenAI multimodal blocks usually use type=image_url
                has_image = True
            elif "image_url" in blk:
                # Fallback for non-standard but equivalent payloads
                has_image = True

        return "\n".join(text_parts).strip(), has_text, has_image

    # fallback for unknown input types
    text = str(user_message)
    return text, bool(text.strip()), False


def extract_user_message_content(context: dict | None = None) -> Dict[str, Any]:
    """
    Guardrails action that reads `context["user_message"]` and returns a
    normalized payload for downstream safety checks.

    Args:
        context: Guardrails action context. `context["user_message"]` may be
          plain text or OpenAI-style multimodal content blocks.

    Returns:
        dict: {
            "text": "<extracted text for text-only rails>",
            "has_text": <bool indicating text blocks exist>,
            "has_image": <bool indicating image blocks exist>
        }

    Typical usage:
    - `self_check_output` and other text rails consume "text".
    - `content_safety_check_input $model=vision_rails` can branch on
      "has_image" and use multimodal checks when needed.
    """
    user_message = ""
    if context is not None:
        user_message = context.get("user_message", "")

    text, has_text, has_image = _parse_user_message_content(user_message)
    return {"text": text, "has_text": has_text, "has_image": has_image}


def replace_text_in_messages(messages: Any, text: str) -> Any:
    """
    Put normalized text back into a Guardrails/OpenAI-style message payload
    while preserving the original shape whenever possible.

    Supported input shapes:
    - `str`: replaced directly with the new text.
    - `list[dict]`: OpenAI-style content blocks where the first
      `type="text"` block is replaced with the new text, any additional text
      blocks are cleared, and image blocks are preserved unchanged.
    - any other type: falls back to the new text string.

    Args:
        messages: A message payload from Guardrails context. Supported shapes
          include plain text (`str`), OpenAI-style content blocks
          (`list[dict]`), or any fallback type.
        text: The normalized text that should be written back into the message
          payload.

    Returns:
        The updated message payload with the provided text written back using
        the closest matching original shape.
    """
    if messages is None:
        return text

    if isinstance(messages, str):
        return text

    if isinstance(messages, list):
        updated_blocks: List[Any] = []
        has_text_block = False
        replaced_first_text_block = False

        for block in messages:
            if not isinstance(block, dict):
                updated_blocks.append(block)
                continue

            updated_block = dict(block)
            if updated_block.get("type") == "text":
                has_text_block = True
                if not replaced_first_text_block:
                    updated_block["text"] = text
                    replaced_first_text_block = True
                else:
                    updated_block["text"] = ""

            updated_blocks.append(updated_block)

        if not has_text_block:
            updated_blocks.insert(0, {"type": "text", "text": text})

        return updated_blocks

    return text
