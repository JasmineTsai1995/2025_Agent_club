import os
import json
import inspect
from typing import Optional

from nemoguardrails import RailsConfig
from nemoguardrails.actions import action

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)


@action(execute_async=True)
async def check_blocked_terms(context: Optional[dict] = None):
    with open(f'{parent_dir}/project_config.json') as json_file:
        project_config = json.load(json_file)
    
    function_name = inspect.currentframe().f_code.co_name
    if function_name not in project_config:
        return True
    bot_response = context.get("bot_message")
    # A quick hard-coded list of proprietary terms. You can also read this from a file.
    proprietary_terms = project_config[function_name]['blocked']

    for term in proprietary_terms:
        if term in bot_response.lower():
            return False

    return True
