import configparser
import json
import logging
import os
import sys
from typing import Any

from nemoguardrails.rails.llm.config import Model
from nemoguardrails.server.api import register_logger
from rich.console import Console
from rich.text import Text

config_parser = configparser.ConfigParser()
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

console = Console()


class CustomLogger:
    """Simple Rich-based logger for prompt and response traces."""

    def __init__(self):
        self.console = console

    def log(self, message: str, message_type: str | None = None):
        styled_message = Text()
        styled_message.append(message, style="cyan bold")
        self.console.print(styled_message)


custom_logger = CustomLogger()


def _disable_broken_local_proxy():
    """Clear known-bad local proxy settings before model clients are created."""
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
        value = os.environ.get(key, "")
        if "127.0.0.1:9" in value or "localhost:9" in value:
            os.environ.pop(key, None)


def setup_custom_logging():
    """Register a lightweight custom log handler."""

    class SimpleHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            if "Event ::" in msg:
                print("Event ::")
                custom_logger.log(msg)
            elif "Prompt ::" in msg or "Response ::" in msg:
                print("Prompt ::")
                custom_logger.log(msg)
            else:
                print("Else ::")
                custom_logger.log(msg)

    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    handler = SimpleHandler()
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)

    root_logger.addHandler(handler)
    root_logger.setLevel(logging.INFO)


async def custom_logger_function(item: Any):
    """Forward prompt/response payloads to the custom logger."""
    if isinstance(item, dict) and item.get("type") in ["input", "output"]:
        message = json.dumps(item.get("content", ""), ensure_ascii=False)
        custom_logger.log(message, item["type"])


def init(app):
    _disable_broken_local_proxy()

    config_parser.read(f"{current_dir}/env.ini")
    active_pipeline = os.environ["PIPELINE_ACTIVE"]
    openai_api_key = os.environ[f"API_KEY_{config_parser[active_pipeline]['name']}"]

    model = Model(
        type="main",
        engine="openai",
        parameters={
            "openai_api_base": "http://dat-cm-rs-litellm:8000/v1",
            "openai_api_key": openai_api_key,
            "model_name": "gemma-4-31B-it-fb8-block",
            "temperature": 0,
            "frequency_penalty": 0.75,
            "top_p": 0.8,
        },
    )
    vision_model = Model(
        type="vision_rails",
        engine="openai",
        parameters={
            "openai_api_base": "http://dat-cm-rs-litellm:8000/v1",
            "openai_api_key": openai_api_key,
            "model_name": "gemma-4-31B-it-fb8-block",
            "temperature": 0,
            "frequency_penalty": 0.75,
            "top_p": 0.8,
        },
    )

    app.config.models = [model, vision_model]
    setup_custom_logging()
    register_logger(custom_logger_function)
    
    
