## setup
#is_dev = True
## 設定
import asyncio
import threading
import requests
from typing import Set, Union ,Optional, List, Dict, Any
from pydantic import BaseModel, Field, root_validator
import pandas as pd
import datetime
import pytz
import warnings
warnings.filterwarnings('ignore')
from routers import config_server
import os
from cxi_utils_func.utils_func import LogFormat
import time
import logging
from nemoguardrails import RailsConfig, LLMRails
import os
import json
from functools import lru_cache
taipei_timezone = pytz.timezone('Asia/Taipei')
directory = '/guardrails'

# 獲取所有子目錄
guardrails_configs = [d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))]
rails={}
project_configs= {}
for config_id in guardrails_configs:
    rails[config_id] = LLMRails(RailsConfig.from_path(f"/guardrails/{config_id}"),verbose=False)
    with open(f"/guardrails/{config_id}/project_config.json") as json_file:
        project_configs[config_id] = json.load(json_file)
     

# ---------------------Logging Setting------------------------
f_format = "[%(asctime)s][%(process)d][%(levelname)s][%(funcName)s] %(message)s"
formatter = logging.Formatter(f_format, datefmt="%Y-%m-%d %H:%M:%S")

logger = logging.getLogger("guardrails")
logger.setLevel(logging.INFO)

logger.propagate = False

if not logger.handlers:
    console_handler = logging.StreamHandler()  # 終端機輸出
    console_handler.setFormatter(formatter)  # 設定格式
    logger.addHandler(console_handler)  # 加入 Handler

logging.getLogger("nemoguardrails").setLevel(logging.CRITICAL)
logging.getLogger("transformers").setLevel(logging.CRITICAL)
logging.getLogger("openai").setLevel(logging.CRITICAL)
# ---------------------Logging Setting------------------------

## 全域變數
from flask import Blueprint, jsonify, request, Response

router = Blueprint('router', __name__)

from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class RailsOptions(BaseModel):
    input: bool = False
    output: bool = False
    retrieval: bool = False
    dialog: bool = False

    @root_validator(pre=True)
    def convert_list_to_dict(cls, values):
        """
        允許 rails 可以是：
        1. `{"input": True, "output": False, "retrieval": False, "dialog": False}`
        2. `["input"]` (表示 `input=True`，其他為 `False`)
        """
        if isinstance(values, list):  # 如果是列表格式
            default_values = {"input": False, "output": False, "retrieval": False, "dialog": False}
            for key in values:
                if key in default_values:
                    default_values[key] = True
            return default_values
        return values  # 否則保持原樣

class LogOptions(BaseModel):
    activated_rails: bool = False
    llm_calls: bool = False
    internal_events: bool = False
    colang_history: bool = False

class Options(BaseModel):
    rails: Union[RailsOptions, List[str]] = RailsOptions()
    llm_params: Dict[str, Any] = {}
    llm_output: bool = False
    output_vars: bool = False
    log: LogOptions = LogOptions()

    @root_validator(pre=True)
    def validate_rails(cls, values):
        """
        允許 `rails` 欄位可以是字典或列表
        """
        rails_value = values.get("rails")
        if isinstance(rails_value, list):  # 如果 `rails` 是列表，轉換為 RailsOptions
            values["rails"] = RailsOptions(**RailsOptions.convert_list_to_dict(rails_value))
        return values

class Guardrails_input(BaseModel):
    user: Optional[str] = None
    config_id: Optional[str] = None
    config_ids: Optional[List[str]] = None
    thread_id: str = "default_thread_id"
    messages: List[Dict[str, Any]] = Field(..., min_items=1, description="必須提供至少一個 message")
    context: Dict[str, Any] = {}
    stream: bool = False
    options: Options = Options()
    state: Dict[str, Any] = {}

    @root_validator(pre=True)
    def check_config_id_or_config_ids(cls, values):
        config_id = values.get("config_id")
        config_ids = values.get("config_ids")
        
        # 確保 `config_id` 或 `config_ids` 至少有一個被提供
        if not config_id and not config_ids:
            raise ValueError("`config_id` 或 `config_ids` 必須至少提供一個")
        
        return values

def remove_none_values(d):
    """ 遞歸刪除 dict 中所有值為 None 的 key """
    if isinstance(d, dict):
        return {k: remove_none_values(v) for k, v in d.items() if v is not None}
    elif isinstance(d, list):
        return [remove_none_values(v) for v in d]
    else:
        return d

def filter_log_fields(data, input_option):
    """
    根據 user_preferences 過濾 log 欄位，保留原始格式
    """
    if input_option['output_vars'] == False:
        del data['output_data']
    log_count = 4
    del data['log']['stats']
    for log_active in input_option['log']:
        if input_option['log'][log_active] == False:
            del data['log'][log_active]
            log_count-=1
    if log_count==0:
        del data['log']
    return data

def log_process(row_log):
    logger.info('send log to postgresql start')

    columns = ', '.join(row_log.keys())
    values = []

    for v in row_log.values():
        if isinstance(v, (dict, list)):
            # 將 dict 或 list 轉成 JSON 字串
            json_str = json.dumps(v).replace("'", "''")  # 避免 SQL 單引號錯誤
            values.append(f"'{json_str}'")
        elif isinstance(v, str):
            # 處理字串中的單引號
            safe_str = v.replace("'", "''")
            values.append(f"'{safe_str}'")
        else:
            values.append(str(v))

    values_str = ', '.join(values)
    insert_query = f"INSERT INTO public.genai_guardrails_log ({columns}) VALUES ({values_str})"
    logger.info(insert_query)

    try:
        print('send log to postgresql')
        requests.post(
            "http://dat-cm-rs-ocp-tool/execute_query_postgresql",
            json={
                "database": "datdatcm",
                "sql": insert_query
            },
            timeout=15
        )
    except requests.exceptions.Timeout:
        logger.warning('Log to postgresql Timeout: please check "dat-cm-rs-ocp-tool" log')
    except Exception as e:
        logger.error(f'Log to postgresql error: {e}')



def log_format(input,output,api_key_info):
    activated_rail_duration_list=[]
    for activated_rail in output['log']['activated_rails']:
        activated_rail_duration_list.append(str(round(activated_rail['duration'],3)))
    total_duration = round(output['log']['stats']['total_duration'],3)
    activated_rail_duration = " | ".join(activated_rail_duration_list)
    config_id = input['config_id']
    user = input['user']
    max_n_context=0
    for c in project_configs[input['config_id']]:
        if 'n_context' in project_configs[input['config_id']][c] and project_configs[input['config_id']][c]['n_context']>max_n_context:
            max_n_context=int(project_configs[input['config_id']][c]['n_context'])
    message_context = input['messages'][-max_n_context:]
    config_parameters = project_configs[input['config_id']]
    user_message = output['output_data'].get('user_message','')
    bot_message = output['output_data'].get('bot_message','')
    input_flows = " | ".join(output['output_data'].get('input_flows',[""]))
    output_flows = " | ".join(output['output_data'].get('output_flows',[""]))
    triggered_input_rail = output['output_data'].get('triggered_input_rail','')
    triggered_output_rail = output['output_data'].get('triggered_output_rail','')
    allowed = output['output_data'].get('allowed','')
    row_log = {"config_id":config_id, 
               "end_user":user,
               "user_message":user_message, 
               "bot_message":bot_message,
               "message_context":message_context,
               "config_parameters":config_parameters,
               "allowed":allowed, 
               "input_flows":input_flows, 
               "output_flows":output_flows, 
               "triggered_input_rail":triggered_input_rail, 
               "triggered_output_rail":triggered_output_rail,
               "activated_rail_duration": activated_rail_duration,
               "total_duration":total_duration,
               "trigger_time": f"{datetime.datetime.now(taipei_timezone)}"}
    for row in row_log:
        if row_log[row] is None:
            row_log[row] = ''
    if not allowed:
        logger.info(f'[DENIED] {row_log}')
    if not cathay_no_check(api_key_info['info']['key_alias']):
        threading.Thread(target=lambda: log_process(row_log)).start()

    
@router.get("/")
def root():
    # 檢查是否為瀏覽器請求（Accept: text/html）
    # accept_header = request.headers.get("accept", "")
    # if "text/html" in accept_header:
    #     return RedirectResponse(url="/docs")  # 跳轉到 Swagger UI
    
    return {"status": "ok"}  # 返回 JSON 給 API 客戶端

@router.get("/v1/rails/configs")
def get_configs():
    return [{"id": guardrails_config} for guardrails_config in guardrails_configs]

def cathay_no_check(s):
    return len(s) == 8 and s.isdigit()

#@lru_cache(maxsize=100)
def generate(api_key_info,input_data_dict_string):
    data = json.loads(input_data_dict_string)
    config_id=data['config_id']
    if cathay_no_check(api_key_info['info']['key_alias']):
        config_id+='_PERSON'
        logger.info(f'PERSON MOD')
    return rails[config_id].generate(messages = data['messages'], options = data['options'])

key_list={}
def check_key_expires(api_key):
    if api_key in key_list:
        if key_list[api_key]['key_expires'] > time.time():
            return True
    return False


def remote_verify_api_key(api_key: str, config_id: str) -> bool:
    """
    呼叫遠端 API 驗證 API Key，並緩存結果，減少重複呼叫。
    """
    verify_api_key={"status":False,"message":""}
    if check_key_expires(api_key):
        if config_id in key_list[api_key]['info']['metadata']['nemo_guardrails']:
            verify_api_key["status"] = True
            verify_api_key["message"] = key_list[api_key]
            return verify_api_key
    try:
        headers = {
            "x-goog-api-key": os.environ['ADMIN_TOKEN'],
            "Content-Type": "application/json"
        }
        verify_url = f"http://dat-cm-rs-litellm:8000/key/info?key={api_key}"
        response = requests.get(verify_url, headers=headers, timeout=5)
        
        if response.status_code == 200:
            result = response.json()
            key_expires = time.time() + 600 #10分鐘過期
            result['key_expires'] = key_expires
            key_list[api_key] = result
            if config_id in key_list[api_key]['info']['metadata']['nemo_guardrails']:
                verify_api_key["status"] = True
                verify_api_key["message"] = key_list[api_key]
            else: 
                verify_api_key["status"] = False
                verify_api_key["message"] = f"API Key does not have permission to {config_id}"
        else:
            verify_api_key["status"] = False
            verify_api_key["message"] = response.json()
        return verify_api_key
        
    except Exception as e:
        logger.error(f"API Key remote verification failed: {e}")
        verify_api_key["status"] = False
        verify_api_key["message"] = e
        return verify_api_key

@router.post("/v1/chat/completions")
def completions():
    input_data = Guardrails_input(**request.json)
    verify_api_key = remote_verify_api_key(request.headers.get("x-goog-api-key"),input_data.config_id)
    if verify_api_key['status']:
        data = input_data.dict()
        logger.info(f'[INPUT] {data}')
        input = input_data.dict()
        # log 內容篩選處理
        data['options']['output_vars']=True
        data['options']['log']['activated_rails']=True
        # guardrails
        response = generate(verify_api_key['message'],json.dumps({key: data[key] for key in ['config_id','messages','options'] if key in data}))
        response = response.model_dump()
        response["messages"] = response.pop("response")
        log_format(input,response,verify_api_key['message'])
        response = filter_log_fields(response, input['options'])
        response = remove_none_values(response)
        return Response(json.dumps(response, ensure_ascii=False), mimetype="application/json")
    else:
        return Response(json.dumps(f'please check "api-key", message: {verify_api_key["message"]}', ensure_ascii=False), mimetype="application/json"),401