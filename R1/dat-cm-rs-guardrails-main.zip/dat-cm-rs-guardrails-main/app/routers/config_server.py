import requests
import os
#http://10.166.156.10:8080/cmn-au-rs-soc-processor/sit

url=f'{os.environ["CFG_SERVER"]}/{os.environ["PROJECT_NAME"]}/{os.environ["PIPELINE_ACTIVE"]}'
print(url)
res=requests.get(url)

for i in res.json()['propertySources']:
    for k in i['source'].keys():
        os.environ[k]=str(i['source'][k])
        
