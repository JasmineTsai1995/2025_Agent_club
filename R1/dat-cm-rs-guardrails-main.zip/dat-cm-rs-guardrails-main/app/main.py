# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 15:46:54 2021

@author: Dicy, Abner
"""
from typing import Optional, Set, List
from prometheus_fastapi_instrumentator import Instrumentator
import json
import os
import base64
import time
from routers import main
import datetime

#from risk_molde import risk_molde
# ==================Log Config=================================
# logging.basicConfig(
            # level=logging.INFO,
            # format='[%(asctime)s] [%(name)-12s] [%(process)d] [%(levelname)s] [%(funcName)s] %(message)s',
            # datefmt='%m-%d %H:%M')
# ============================================================


description = "* SOURCECHANNEL: 通路應用代號\n* TXNSEQ: 來源交易序號\n* 最後修改時間: {t}\n".format(t=datetime.datetime.now())
from flask import Flask

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False 
# app = FastAPI(
#         # docs_url="/",
#         title="nemo Guardrails",
#         description= description
#     )

# 啟用 Prometheus 監控
# Instrumentator().instrument(app).expose(app, tags=["Monitoring"])

# ----------Self-hosting JavaScript and CSS for docs----------
# app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/docs")
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=app.title + " - Swagger UI",
        swagger_js_url="/static/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger-ui.css",
    )


@app.get("/redoc")
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=app.title + " - ReDoc",
        redoc_js_url="/static/redoc.standalone.js",
    )
    
# ----------Self-hosting JavaScript and CSS for docs----------

# --------------------Set router--------------------
# app.include_router(main.router)
app.register_blueprint(main.router)
# --------------------Set router--------------------


@app.get("/healthy_check")
async def root():
    return {"Healthy": "True"}
