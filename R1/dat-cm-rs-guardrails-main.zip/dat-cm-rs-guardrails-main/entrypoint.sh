# export UVICORN_LOG_LEVEL=error
# nemoguardrails server --config guardrails --port 8000 --disable-chat-ui --verbose
# uvicorn main:app --port 8000 --host 0.0.0.0 --workers 4  --log-config /app/static/uvicorn_config.json

cd app
gunicorn main:app -b 0.0.0.0 -w 4